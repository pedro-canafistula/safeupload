// Managed mirror of driver/SafeUpload.Minifilter/Protocol.h.
//
// Protocol.h is the source of truth. Every structure here exists to match
// it byte for byte, and Contract.Verify() checks that claim at startup
// rather than letting a mismatch surface as a corrupted path string.
//
// The layout rules that make this safe to mirror at all, restated from
// Protocol.h: fixed-size structures, explicit field widths, field order
// chosen so there is no implicit padding. Nothing here may use a type
// whose size depends on the runtime or on the process bitness.

using System;
using System.Runtime.InteropServices;

namespace SafeUpload.Agent.Minifilter;

public static class Contract
{
    public const string PortName = @"\SafeUploadPort";

    /// <summary>
    /// Must equal SAFEUPLOAD_PROTOCOL_VERSION in Protocol.h. The driver
    /// rejects any message carrying a different value, which is the
    /// mechanism that turns an incompatible pair into a clean refusal
    /// instead of a misread structure.
    /// </summary>
    public const uint Version = 18;

    public const int MaxPathChars = 512;
    public const int MaxImageNameChars = 64;

    public const int MaxExtensions = 32;
    public const int MaxExtensionChars = 16;
    public const int MaxPrefixes = 16;
    public const int MaxPrefixChars = 260;
    public const int MaxSourcePrefixes = 16;
    public const int MaxImages = 16;
    public const int MaxImageChars = 64;

    // Sizes asserted by C_ASSERT on the kernel side. Duplicated here on
    // purpose: if the two ever disagree, Verify() says so by name.
    public const int RequestSize = 1192;
    public const int ResponseSize = 152;
    public const int MaxStageNameChars = 64;
    public const int ControlSize = 16;
    public const int PolicyMessageSize = 19752;
    // SafeUploadControl.Reserved on SET_POLICY. Sent only after the boot
    // policy's committed registry value is durable and its pending union is removed.
    public const uint FinalizeDurableBootScopes = 1;
    public const int CountersSize = 184;
    public const int OverrideMessageSize = 1056;
    public const int AdmissionCoverageMaxScopes = 98;
    public const int AdmissionCoverageScopeSize = 556;
    public const int AdmissionCoverageStatusSize = 54664;

    /// <summary>
    /// Throws if any managed structure fails to match the size the driver
    /// asserts for its C counterpart.
    ///
    /// Call this before connecting. A layout mismatch found here is a
    /// one-line error message; the same mismatch found at run time is a
    /// verdict answered for the wrong request, and nothing in the system
    /// would report it as an error.
    /// </summary>
    public static unsafe void Verify()
    {
        Check(nameof(SafeUploadRequest), sizeof(SafeUploadRequest), RequestSize);
        Check(nameof(SafeUploadResponse), sizeof(SafeUploadResponse), ResponseSize);
        Check(nameof(SafeUploadControl), sizeof(SafeUploadControl), ControlSize);
        Check(nameof(SafeUploadPolicyMessage), sizeof(SafeUploadPolicyMessage), PolicyMessageSize);
        Check(nameof(SafeUploadCounters), sizeof(SafeUploadCounters), CountersSize);
        Check(nameof(SafeUploadOverrideMessage), sizeof(SafeUploadOverrideMessage), OverrideMessageSize);
        Check(nameof(SafeUploadPublicationMessage), sizeof(SafeUploadPublicationMessage), 2128);
        Check(nameof(SafeUploadAdmissionCoverageScope), sizeof(SafeUploadAdmissionCoverageScope),
              AdmissionCoverageScopeSize);
        Check(nameof(SafeUploadAdmissionCoverageStatus), sizeof(SafeUploadAdmissionCoverageStatus),
              AdmissionCoverageStatusSize);
        CheckOffset(nameof(SafeUploadPublicationMessage) + ".TemporaryPath",
                    (int) Marshal.OffsetOf<SafeUploadPublicationMessage>(nameof(SafeUploadPublicationMessage.TemporaryPath)), 80);

        // Offsets that carry real risk: everything after them shifts if
        // they are wrong, and a shifted path is still a readable string.
        CheckOffset(nameof(SafeUploadRequest) + ".Path",
                    (int) Marshal.OffsetOf<SafeUploadRequest>(nameof(SafeUploadRequest.Path)), 40);
        CheckOffset(nameof(SafeUploadRequest) + ".ImageName",
                    (int) Marshal.OffsetOf<SafeUploadRequest>(nameof(SafeUploadRequest.ImageName)), 1064);
        CheckOffset(nameof(SafeUploadResponse) + ".StageName",
                    (int) Marshal.OffsetOf<SafeUploadResponse>(nameof(SafeUploadResponse.StageName)), 24);
        CheckOffset(nameof(SafeUploadPolicyMessage) + ".Prefixes",
                    (int) Marshal.OffsetOf<SafeUploadPolicyMessage>(nameof(SafeUploadPolicyMessage.Prefixes)), 1064);
        CheckOffset(nameof(SafeUploadPolicyMessage) + ".SourcePrefixes",
                    (int) Marshal.OffsetOf<SafeUploadPolicyMessage>(nameof(SafeUploadPolicyMessage.SourcePrefixes)), 9384);
        CheckOffset(nameof(SafeUploadPolicyMessage) + ".Images",
                    (int) Marshal.OffsetOf<SafeUploadPolicyMessage>(nameof(SafeUploadPolicyMessage.Images)), 17704);
        CheckOffset(nameof(SafeUploadCounters) + ".TaintHits",
                    (int) Marshal.OffsetOf<SafeUploadCounters>(nameof(SafeUploadCounters.TaintHits)), 96);
        CheckOffset(nameof(SafeUploadAdmissionCoverageStatus) + ".Scopes",
                    (int) Marshal.OffsetOf<SafeUploadAdmissionCoverageStatus>(nameof(SafeUploadAdmissionCoverageStatus.Scopes)), 176);
    }

    private static void Check(string name, int actual, int expected)
    {
        if (actual != expected)
        {
            throw new InvalidOperationException(
                $"{name} tem {actual} bytes, o driver espera {expected}. " +
                "Protocol.cs saiu de sincronia com Protocol.h.");
        }
    }

    private static void CheckOffset(string name, int actual, int expected)
    {
        if (actual != expected)
        {
            throw new InvalidOperationException(
                $"{name} esta no offset {actual}, o driver espera {expected}. " +
                "Protocol.cs saiu de sincronia com Protocol.h.");
        }
    }
}

public static class Operation
{
    public const uint Create = 1;
    public const uint StageAllocate = 3;
    public const uint StageSeal = 4;
    public const uint StageRename = 5;
    public const uint StageDiagnostic = 6;
    public const uint StageRenameCommit = 7;
    public const uint StageRenameAbort = 8;

    /// <summary>
    /// Kept for contract completeness. The driver no longer registers
    /// IRP_MJ_READ, so this value does not appear in practice - see the
    /// comment on the registration table in Filter.c for why.
    /// </summary>
    public const uint Read = 2;
}

public static class Verdict
{
    public const uint Allow = 0;
    public const uint Deny = 1;
}

[Flags]
public enum RequestFlags : uint
{
    None = 0,
    PathTruncated = 0x00000001,
    ImageNameTruncated = 0x00000002,
    PathNotNormalized = 0x00000004,

    /// <summary>The create is heading into a monitored destination.</summary>
    ScopeDestination = 0x00000008,

    /// <summary>The create is reading from a monitored source.</summary>
    ScopeSource = 0x00000010,
    StageFollowup = 0x00000020,
    StageRemovable = 0x00000040,
    StageNetwork = 0x00000080,
    StageTombstoneCreate = 0x00000100,
}

[Flags]
public enum PolicyFlags : uint
{
    None = 0,
    Removable = 0x00000001,
    Network = 0x00000002,

    /// <summary>
    /// Avalia tudo, registra tudo, nao nega nada.
    ///
    /// Precisa chegar ao kernel, e nao ficar so no servico: a recusa por
    /// processo marcado acontece la sem perguntar a ninguem. A marcacao
    /// continua acontecendo - sem ela nao ha o que medir.
    /// </summary>
    AuditOnly = 0x00000004,

    /// <summary>
    /// Deixa o usuario justificar uma recusa e seguir.
    ///
    /// Dois modos, e so dois. Desligado, o mecanismo fica fora do ar: o
    /// driver recusa conceder excecao, entao nem uma interface comprometida
    /// libera nada. A escolha e da organizacao, nao do usuario.
    /// </summary>
    AllowOverride = 0x00000008,

    /// <summary>Classify supported file reads on every attached volume.</summary>
    ClassifyAllSources = 0x00000010,

    /// <summary>Feature-build qualification: bypass process-taint recording and lookup.</summary>
    TestDisableTaint = 0x00000020,
}

public static class ControlCommand
{
    public const uint SetPolicy = 1;
    public const uint GetCounters = 2;
    public const uint GrantOverride = 3;
    public const uint StagePublication = 4;
    public const uint AdmissionCoverage = 24;
}


public static class AdmissionCoverageContract
{
    public const uint Pending = 0;
    public const uint Ready = 1;
    public const uint Degraded = 2;
    public const uint PrefixScope = 1;
    public const uint RemovableScope = 2;
    public const uint NetworkScope = 3;
    public const uint UnknownResolution = 0;
    public const uint AbsentResolution = 1;
    public const uint UniqueResolution = 2;
    public const uint AmbiguousResolution = 3;
    public const uint NotApplicableResolution = 4;
    public const uint CompleteFlag = 0x00000001;
    public const uint StableFlag = 0x00000002;
    public const uint FutureGateFlag = 0x00000004;
    public const uint PolicyPendingFlag = 0x00000008;
    public const uint RegistryCompleteFlag = 0x00000010;
    public const uint PolicyScopeOverflowFlag = 0x00000020;
    public const uint TestTaintControlFlag = 0x00000040;
}

[StructLayout(LayoutKind.Sequential, Pack = 8)]
public unsafe struct SafeUploadAdmissionCoverageScope
{
    public uint ScopeKind;
    public uint ScopeIndex;
    public uint Resolution;
    public uint State;
    public uint Reason;
    public uint MatchingInstances;
    public uint UniqueVolumes;
    public uint ReadyInstances;
    public uint PrefixChars;
    public fixed char Prefix[Contract.MaxPrefixChars];

    public string ReadPrefix()
    {
        uint chars = Math.Min(PrefixChars, (uint) Contract.MaxPrefixChars);
        fixed (char* value = Prefix) return new string(value, 0, (int) chars);
    }
}

[StructLayout(LayoutKind.Sequential, Pack = 8)]
public unsafe struct SafeUploadAdmissionCoverageStatus
{
    public uint StructSize;
    public uint ProtocolVersion;
    public uint State;
    public uint Flags;
    public uint PolicyGeneration;
    public uint PolicyFlags;
    public uint BootPolicyState;
    public uint ScopeCount;
    public uint ExpectedScopeCount;
    public uint PolicyGenerationEnd;
    public uint PolicyFlagsEnd;
    public uint BootPolicyStateEnd;
    public uint EpochGeneration;
    public uint EpochFlags;
    public uint EpochActiveCallbacks;
    public uint EpochGenerationEnd;
    public uint EpochFlagsEnd;
    public uint EpochActiveCallbacksEnd;
    public uint EnumeratedInstances;
    public uint SetupInFlight;
    public uint TeardownInFlight;
    public uint CoverageChangesInFlight;
    public uint WriterGlobalUnknown;
    public uint WriterEntries;
    public uint WriterEntriesNotReady;
    public uint WriterEntriesUnknown;
    public uint FutureMountGateReady;
    public uint Reason;
    public ulong PolicyScopeSequenceStart;
    public ulong PolicyScopeSequenceEnd;
    public ulong TopologySequenceStart;
    public ulong TopologySequenceEnd;
    public ulong CoverageSequenceStart;
    public ulong CoverageSequenceEnd;
    public ulong RegistrySequenceStart;
    public ulong RegistrySequenceEnd;
    public fixed byte Scopes[Contract.AdmissionCoverageMaxScopes * Contract.AdmissionCoverageScopeSize];

    public SafeUploadAdmissionCoverageScope GetScope(int index)
    {
        if ((uint) index >= ScopeCount || index >= Contract.AdmissionCoverageMaxScopes)
            throw new ArgumentOutOfRangeException(nameof(index));
        fixed (byte* data = Scopes)
            return ((SafeUploadAdmissionCoverageScope*) data)[index];
    }
}

[StructLayout(LayoutKind.Sequential, Pack = 8)]
public unsafe struct SafeUploadRequest
{
    public uint Version;
    public uint StructSize;
    public ulong RequestId;
    public uint Operation;
    public uint RequestorProcessId;
    public uint Flags;
    public uint PathLength;      // bytes, excluding the terminator
    public uint ImageNameLength; // bytes, excluding the terminator
    public uint Reserved;
    public fixed char Path[Contract.MaxPathChars];
    public fixed char ImageName[Contract.MaxImageNameChars];

    public RequestFlags TypedFlags => (RequestFlags) Flags;

    public bool HasKnownFlags
    {
        get
        {
            const uint v18Known = 0x000001ff;
            const uint known = v18Known;
            return (Flags & ~known) == 0;
        }
    }

    public string GetPath()
    {
        fixed (char* p = Path) { return Read(p, PathLength, Contract.MaxPathChars); }
    }

    public string GetImageName()
    {
        fixed (char* p = ImageName) { return Read(p, ImageNameLength, Contract.MaxImageNameChars); }
    }

    // The length field is in bytes and comes from the kernel. It is
    // trusted only after being clamped: a client that indexes straight
    // into a fixed buffer with a value it did not verify is one bad
    // message away from reading past the structure.
    private static string Read(char* buffer, uint lengthInBytes, int capacityInChars)
    {
        int chars = (int) (lengthInBytes / sizeof(char));

        if (chars < 0 || chars > capacityInChars)
        {
            chars = capacityInChars;
        }

        return new string(buffer, 0, chars);
    }
}

[StructLayout(LayoutKind.Sequential, Pack = 8)]
public unsafe struct SafeUploadResponse
{
    public uint Version;
    public uint StructSize;
    public ulong RequestId;
    public uint Verdict;
    public uint StageNameLength;
    public fixed char StageName[Contract.MaxStageNameChars];
}

[StructLayout(LayoutKind.Sequential, Pack = 8)]
public struct SafeUploadControl
{
    public uint Version;
    public uint StructSize;
    public uint Command;
    public uint Reserved;
}


[StructLayout(LayoutKind.Sequential, Pack = 8)]
public unsafe struct SafeUploadPolicyMessage
{
    public SafeUploadControl Control;

    public uint ExtensionCount;
    public uint PrefixCount;
    public uint ImageCount;
    public uint SourcePrefixCount;
    public uint Flags;

    /// <summary>
    /// Quanto o kernel espera por um veredito, em milissegundos.
    ///
    /// Vem da politica e nao de uma constante no driver porque o prazo e da
    /// inspecao, nao do transporte: a RN-012 da um orcamento ao motor, e ter
    /// o mesmo numero escrito em dois lugares e como os dois divergem. Zero
    /// significa "use o padrao do driver". O driver limita o valor.
    /// </summary>
    public uint VerdictTimeoutMs;

    public fixed char Extensions[Contract.MaxExtensions * Contract.MaxExtensionChars];
    public fixed char Prefixes[Contract.MaxPrefixes * Contract.MaxPrefixChars];
    public fixed char SourcePrefixes[Contract.MaxSourcePrefixes * Contract.MaxPrefixChars];
    public fixed char Images[Contract.MaxImages * Contract.MaxImageChars];
}

/// <summary>
/// Concessao de excecao, do servico para o driver.
///
/// O caminho e exato, e nao prefixo: uma excecao para uma pasta valeria para
/// tudo que fosse escrito nela depois. O prazo e limitado pelo driver, porque
/// uma excecao e um buraco na protecao e um que dure uma hora e um buraco com
/// nome.
/// </summary>
[StructLayout(LayoutKind.Sequential, Pack = 8)]
public unsafe struct SafeUploadOverrideMessage
{
    public SafeUploadControl Control;
    public uint ProcessId;
    public uint DurationSeconds;
    public uint PathLength;
    public uint Reserved;
    public fixed char Path[Contract.MaxPathChars];
}

[StructLayout(LayoutKind.Sequential, Pack = 8)]
public unsafe struct SafeUploadPublicationMessage
{
    public SafeUploadControl Control;
    public Guid TransferId;
    public uint Revoke;
    public uint TemporaryPathLength;
    public uint DestinationPathLength;
    public uint Reserved;
    public fixed byte Digest[32];
    public fixed char TemporaryPath[Contract.MaxPathChars];
    public fixed char DestinationPath[Contract.MaxPathChars];
}

[StructLayout(LayoutKind.Sequential, Pack = 8)]
public struct SafeUploadCounters
{
    public uint Version;
    public uint StructSize;

    public ulong CreatesSeen;
    public ulong CreatesPastCheapGates;
    public ulong ScopeEvaluations;
    public ulong UserModeRoundTrips;
    public ulong CacheHits;
    public ulong DeniedPreCreate;
    public ulong DeniedPostCreate;
    public ulong DeniedRename;
    public ulong AllowedWithoutInspection;
    public ulong TaintsRecorded;
    public ulong TaintLookups;
    public ulong TaintHits;
    public ulong SetInformationSeen;
    public ulong RenamesSeen;
    public ulong RenamesFromTainted;
    public ulong LinksSeen;
    public ulong LinksFromTainted;
    public ulong WouldHaveDenied;
    public ulong OverridesGranted;
    public ulong OverridesUsed;
    public ulong ClassesSeenLow;
    public ulong ClassesSeenHigh;
}
