/*++

Module Name:

    Filter.c

Abstract:

    Main module of the SafeUpload minifilter.

    The driver registers a pre-operation callback for IRP_MJ_CREATE,
    discards the traffic it has no business arbitrating, and asks a
    user-mode inspector for a verdict before letting the operation through.

    Deliberately, there is NO detection logic in this file. Business rules
    RN-001..RN-004 (CPF, CNPJ, Luhn, password heuristics) live in user
    mode. The kernel only transports.

Environment:

    Kernel mode

--*/

#include "Filter.h"

//
//  Single instance of the global driver state.
//

SAFEUPLOAD_DATA SafeUploadData;

//
//  Cumulative since load, never reset. A reader that wants a rate takes two
//  samples and subtracts.
//

SAFEUPLOAD_COUNTERS SafeUploadCounters;

// Packed into the post-create completion context beside the volume kind.
#define SAFEUPLOAD_POSTCREATE_OVERRIDE 0x10

// Owned-stream staging is explicitly enabled only in the isolated feature
// build. The complete filesystem/destination acceptance matrix is still open.
// Disabled in normal builds; never include it in a production package.
#ifndef SAFEUPLOAD_STAGING_PROTOTYPE
#define SAFEUPLOAD_STAGING_PROTOTYPE 0
#endif

#include "Stage.h"

static
BOOLEAN
SafeUploadIsIgnoredProcess (
    _In_ ULONG ProcessId
    );

static
NTSTATUS
SafeUploadCopyRequestPath (
    _Inout_ PFLT_CALLBACK_DATA Data,
    _Inout_ PSAFEUPLOAD_REQUEST Request
    );

VOID
SafeUploadCopyRequestImageName (
    _In_ PFLT_CALLBACK_DATA Data,
    _Inout_ PSAFEUPLOAD_REQUEST Request
    );

static
BOOLEAN
SafeUploadEvaluate (
    _Inout_ PFLT_CALLBACK_DATA Data,
    _In_ SAFEUPLOAD_VOLUME_KIND VolumeKind,
    _Out_ PUINT32 ScopeFlags,
    _Out_ PUINT32 Verdict
    );

static
BOOLEAN
SafeUploadReadFileStamp (
    _In_ PCFLT_RELATED_OBJECTS FltObjects,
    _Out_ PLARGE_INTEGER FileSize,
    _Out_ PLARGE_INTEGER LastWriteTime
    );

static
BOOLEAN
SafeUploadIsMonitoredDestination (
    _Inout_ PFLT_CALLBACK_DATA Data,
    _In_ SAFEUPLOAD_VOLUME_KIND VolumeKind
    );

static
BOOLEAN
SafeUploadOverrideCovers (
    _Inout_ PFLT_CALLBACK_DATA Data,
    _In_ ULONG ProcessId
    );

static BOOLEAN SafeUploadCreateIsWriter(_In_ PFLT_CALLBACK_DATA Data);
static BOOLEAN SafeUploadFailClosedProtectedCreate(_Inout_ PFLT_CALLBACK_DATA Data,
    _In_ PCFLT_RELATED_OBJECTS FltObjects);
static FLT_PREOP_CALLBACK_STATUS SafeUploadPreAcquireSection(_Inout_ PFLT_CALLBACK_DATA Data,
    _In_ PCFLT_RELATED_OBJECTS FltObjects, _Flt_CompletionContext_Outptr_ PVOID *CompletionContext);

#ifdef ALLOC_PRAGMA
    #pragma alloc_text(INIT, DriverEntry)
    #pragma alloc_text(PAGE, SafeUploadUnload)
    #pragma alloc_text(PAGE, SafeUploadInstanceSetup)
    #pragma alloc_text(PAGE, SafeUploadInstanceQueryTeardown)
    #pragma alloc_text(PAGE, SafeUploadPreCreate)
    #pragma alloc_text(PAGE, SafeUploadCopyRequestPath)
    #pragma alloc_text(PAGE, SafeUploadCopyRequestImageName)
    #pragma alloc_text(PAGE, SafeUploadEvaluate)
    #pragma alloc_text(PAGE, SafeUploadReadFileStamp)
    #pragma alloc_text(PAGE, SafeUploadIsMonitoredDestination)
    #pragma alloc_text(PAGE, SafeUploadOverrideCovers)
    #pragma alloc_text(PAGE, SafeUploadPostCreate)
    #pragma alloc_text(PAGE, SafeUploadPreCleanup)
    #pragma alloc_text(PAGE, SafeUploadPreWrite)
    #pragma alloc_text(PAGE, SafeUploadPreSetInformation)
    #pragma alloc_text(PAGE, SafeUploadFailClosedProtectedCreate)
    #pragma alloc_text(PAGE, SafeUploadPreAcquireSection)

#endif

///////////////////////////////////////////////////////////////////////////
//
//  Registration data handed to the filter manager.
//
///////////////////////////////////////////////////////////////////////////

#if SAFEUPLOAD_STAGING_PROTOTYPE
#define STAGE_OPERATION(major) { major, 0, SafeUploadStageDispatch, SafeUploadStagePostOperation }
static CONST FLT_OPERATION_REGISTRATION Callbacks[] = {
    STAGE_OPERATION(IRP_MJ_CREATE), STAGE_OPERATION(IRP_MJ_CLOSE),
    STAGE_OPERATION(IRP_MJ_READ), STAGE_OPERATION(IRP_MJ_WRITE),
    STAGE_OPERATION(IRP_MJ_QUERY_INFORMATION), STAGE_OPERATION(IRP_MJ_SET_INFORMATION),
    STAGE_OPERATION(IRP_MJ_QUERY_EA), STAGE_OPERATION(IRP_MJ_SET_EA),
    STAGE_OPERATION(IRP_MJ_FLUSH_BUFFERS), STAGE_OPERATION(IRP_MJ_QUERY_VOLUME_INFORMATION),
    STAGE_OPERATION(IRP_MJ_SET_VOLUME_INFORMATION), STAGE_OPERATION(IRP_MJ_DIRECTORY_CONTROL),
    STAGE_OPERATION(IRP_MJ_FILE_SYSTEM_CONTROL), STAGE_OPERATION(IRP_MJ_DEVICE_CONTROL),
    STAGE_OPERATION(IRP_MJ_INTERNAL_DEVICE_CONTROL), STAGE_OPERATION(IRP_MJ_SHUTDOWN),
    STAGE_OPERATION(IRP_MJ_LOCK_CONTROL), STAGE_OPERATION(IRP_MJ_CLEANUP),
    STAGE_OPERATION(IRP_MJ_CREATE_MAILSLOT), STAGE_OPERATION(IRP_MJ_QUERY_SECURITY),
    STAGE_OPERATION(IRP_MJ_SET_SECURITY), STAGE_OPERATION(IRP_MJ_POWER),
    STAGE_OPERATION(IRP_MJ_SYSTEM_CONTROL), STAGE_OPERATION(IRP_MJ_DEVICE_CHANGE),
    STAGE_OPERATION(IRP_MJ_QUERY_QUOTA), STAGE_OPERATION(IRP_MJ_SET_QUOTA),
    STAGE_OPERATION(IRP_MJ_PNP), STAGE_OPERATION(IRP_MJ_ACQUIRE_FOR_SECTION_SYNCHRONIZATION),
    STAGE_OPERATION(IRP_MJ_RELEASE_FOR_SECTION_SYNCHRONIZATION),
    STAGE_OPERATION(IRP_MJ_ACQUIRE_FOR_MOD_WRITE), STAGE_OPERATION(IRP_MJ_RELEASE_FOR_MOD_WRITE),
    STAGE_OPERATION(IRP_MJ_ACQUIRE_FOR_CC_FLUSH), STAGE_OPERATION(IRP_MJ_RELEASE_FOR_CC_FLUSH),
    STAGE_OPERATION(IRP_MJ_FAST_IO_CHECK_IF_POSSIBLE), STAGE_OPERATION(IRP_MJ_NETWORK_QUERY_OPEN),
    STAGE_OPERATION(IRP_MJ_MDL_READ), STAGE_OPERATION(IRP_MJ_MDL_READ_COMPLETE),
    STAGE_OPERATION(IRP_MJ_PREPARE_MDL_WRITE), STAGE_OPERATION(IRP_MJ_MDL_WRITE_COMPLETE),
    STAGE_OPERATION(IRP_MJ_VOLUME_MOUNT), STAGE_OPERATION(IRP_MJ_VOLUME_DISMOUNT),
    STAGE_OPERATION(IRP_MJ_QUERY_OPEN), {IRP_MJ_OPERATION_END}
};

#else
CONST FLT_OPERATION_REGISTRATION Callbacks[] = {
    { IRP_MJ_CREATE, 0, SafeUploadPreCreate, SafeUploadPostCreate },
    { IRP_MJ_CLEANUP, 0, SafeUploadPreCleanup, NULL },
    { IRP_MJ_WRITE, FLTFL_OPERATION_REGISTRATION_SKIP_PAGING_IO, SafeUploadPreWrite, NULL },
    { IRP_MJ_SET_INFORMATION, 0, SafeUploadPreSetInformation, NULL },
    { IRP_MJ_FILE_SYSTEM_CONTROL, 0, SafeUploadStageTxfFsctlPreOperation, NULL },
    { IRP_MJ_ACQUIRE_FOR_SECTION_SYNCHRONIZATION, 0, SafeUploadPreAcquireSection, NULL },
    { IRP_MJ_OPERATION_END }
};
#endif

CONST FLT_REGISTRATION FilterRegistration = {

    sizeof( FLT_REGISTRATION ),         //  Size
    FLT_REGISTRATION_VERSION,           //  Version
#if SAFEUPLOAD_STAGING_PROTOTYPE
    FLTFL_REGISTRATION_DO_NOT_SUPPORT_SERVICE_STOP,
#else
    0,
#endif
    SafeUploadContextRegistration,      //  Context registration
    Callbacks,                          //  Operation callbacks
#if SAFEUPLOAD_STAGING_PROTOTYPE
    SafeUploadUnload,                   // Test build only: the harness restores the original driver.
#else
    NULL,                               // Production build: no voluntary unload callback.
#endif
    SafeUploadInstanceSetup,            //  InstanceSetup
    SafeUploadInstanceQueryTeardown,    //  InstanceQueryTeardown
#if SAFEUPLOAD_STAGING_PROTOTYPE
    SafeUploadStageWritersInstanceTeardownStart,
#else
    NULL,                               //  InstanceTeardownStart
#endif
    NULL,                               //  InstanceTeardownComplete
#if SAFEUPLOAD_STAGING_PROTOTYPE
    SafeUploadStageGenerateName,
    SafeUploadStageNormalizeComponent,
#else
    NULL,
    NULL,
#endif
    NULL,                               // NormalizeContextCleanup
#if SAFEUPLOAD_STAGING_PROTOTYPE
    SafeUploadStageTransactionNotification // TransactionNotificationCallback
#else
    NULL                                // TransactionNotificationCallback
#endif
};

///////////////////////////////////////////////////////////////////////////
//
//  Initialization and teardown.
//
///////////////////////////////////////////////////////////////////////////

NTSTATUS
DriverEntry (
    _In_ PDRIVER_OBJECT DriverObject,
    _In_ PUNICODE_STRING RegistryPath
    )
/*++

Routine Description:

    Initialization routine for the driver. Registers with the filter
    manager and starts filtering.

    IRQL: PASSIVE_LEVEL. Called by the I/O manager in the context of the
    System process while the service is being started. RegistryPath supplies
    the bounded durable policy location read before FltStartFiltering.

Arguments:

    DriverObject - Driver object created by the system for this driver.

    RegistryPath - Where this driver's service parameters live.

Return Value:

    STATUS_SUCCESS once the filter is registered and filtering, otherwise
    the failing status. On any failure nothing stays registered.

--*/
{
    NTSTATUS status;

    //
    //  Opt in to non-paged, non-executable pool for every allocation that
    //  does not name a pool type explicitly. Required for the driver to be
    //  loadable on Windows builds that enforce NX pool.
    //

    ExInitializeDriverRuntime( DrvRtPoolNxOptIn );



    //
    //  Has to be initialized before the port exists, because the first
    //  thing any user of the channel does is acquire it.
    //

    ExInitializeRundownProtection( &SafeUploadData.ChannelRundown );

    //
    //  Also before the port: the first thing a client does after connecting
    //  is push a policy.
    //

    SafeUploadInitializePolicy( RegistryPath );
    SafeUploadInitializeTaint();
    SafeUploadInitializeOverrides();

#if SAFEUPLOAD_STAGING_PROTOTYPE
    status = SafeUploadStageInitialize();
    if (!NT_SUCCESS(status)) goto FreeState;
#endif

    SafeUploadData.DriverObject = DriverObject;

    status = FltRegisterFilter( DriverObject,
                                &FilterRegistration,
                                &SafeUploadData.Filter );

    if (!NT_SUCCESS( status )) {

        SafeUploadTrace( "FltRegisterFilter failed, status 0x%08X\n", status );
        goto FreeState;
    }

    //
    //  From here on the filter manager may call our callbacks, so every
    //  failure path below has to unregister before returning.
    //

    status = SafeUploadCreateCommunicationPort();

    if (!NT_SUCCESS( status )) {
        goto UnregisterFilter;
    }

#if SAFEUPLOAD_STAGING_PROTOTYPE
    status = SafeUploadStageStartWorker();
    if (!NT_SUCCESS(status)) goto ClosePort;
#endif

#if SAFEUPLOAD_STAGING_PROTOTYPE
    if (!SafeUploadData.BootStartMode) {
        /* Preserve Phase 1 demand-load behavior. A boot-start load never
         * performs synchronous volume enumeration or lower file I/O here. */
        status = SafeUploadStageFenceRefresh( NULL );
        if (!NT_SUCCESS( status )) {
            SafeUploadTrace( "pre-start fence scan failed, status 0x%08X\n", status );
            goto ClosePort;
        }
    } else {
        SafeUploadTrace("boot-start mode: scan-based fence refresh is disabled\n");
    }
#endif

    status = FltStartFiltering( SafeUploadData.Filter );

    if (!NT_SUCCESS( status )) {

        SafeUploadTrace( "FltStartFiltering failed, status 0x%08X\n", status );

        goto ClosePort;
    }

#if SAFEUPLOAD_STAGING_PROTOTYPE
    SafeUploadStageAdmissionReady();
    if (!SafeUploadData.BootStartMode) SafeUploadStageFenceStartRetries();
#endif

#if SAFEUPLOAD_STAGING_PROTOTYPE
    if (!SafeUploadData.BootStartMode) {
        /* Demand-start diagnostic path only; boot start remains registry-only. */
        (VOID) SafeUploadStageFenceRefresh( NULL );
    }
#endif

    SafeUploadTrace( "loaded and filtering\n" );

    return STATUS_SUCCESS;

ClosePort:
    // A client can connect after the port is created even if filtering
    // fails to start. Close it and drain any in-flight port callback first.
    SafeUploadCloseCommunicationPort();
    ExWaitForRundownProtectionRelease( &SafeUploadData.ChannelRundown );
#if SAFEUPLOAD_STAGING_PROTOTYPE
    SafeUploadStageStopWorker();
#endif

UnregisterFilter:
    FltUnregisterFilter( SafeUploadData.Filter );
    SafeUploadData.Filter = NULL;

FreeState:
#if SAFEUPLOAD_STAGING_PROTOTYPE
    SafeUploadStageFree();
#endif
    // These were initialized before FltRegisterFilter. In particular, the
    // taint table may have registered a process notification callback; it
    // must be removed even when registration itself failed.
    SafeUploadFreeOverrides();
    SafeUploadFreeTaint();
    SafeUploadFreePolicy();

    return status;
}


NTSTATUS
SafeUploadUnload (
    _In_ FLT_FILTER_UNLOAD_FLAGS Flags
    )
/*++

Routine Description:

    Filter unload callback.

    Two cases have to be told apart:

    - Mandatory unload (FLTFL_FILTER_UNLOAD_MANDATORY): the filter manager
      is not asking, it is telling. A failure status is ignored and the
      driver is torn down regardless, so the only correct behaviour is to
      release everything and return success.

    - Non-mandatory unload: an operator ran "fltmc unload". Here the filter
      is allowed to decline by returning STATUS_FLT_DO_NOT_DETACH.

    IRQL: PASSIVE_LEVEL.

Arguments:

    Flags - FLTFL_FILTER_UNLOAD_MANDATORY when the unload cannot be refused.

Return Value:

    STATUS_SUCCESS to let the unload proceed.

--*/
{
#if SAFEUPLOAD_STAGING_PROTOTYPE
    NTSTATUS status;
#endif

    PAGED_CODE();

    SafeUploadTrace( "unload requested (mandatory=%u)\n",
                     BooleanFlagOn( Flags, FLTFL_FILTER_UNLOAD_MANDATORY ) );

    //
    //  A voluntary unload with the inspector still attached is declined.
    //  Tearing the channel down under a live client is legal but pointless
    //  guesswork for the operator: stopping the inspector first makes the
    //  order of events deterministic. A mandatory unload gets no say.
    //

    if (!FlagOn( Flags, FLTFL_FILTER_UNLOAD_MANDATORY ) &&
        SafeUploadData.ClientPort != NULL) {

        SafeUploadTrace( "declining voluntary unload: inspector still connected\n" );
#if SAFEUPLOAD_STAGING_PROTOTYPE
        SafeUploadStageRecordUnloadVeto(SAFEUPLOAD_UNLOAD_VETO_CLIENT, STATUS_FLT_DO_NOT_DETACH);
#endif

        return STATUS_FLT_DO_NOT_DETACH;
    }

    //
    //  Order matters here.
    //
    //  1. Close the ports. No new connection can be made, and any thread
    //     already blocked inside FltSendMessage is released immediately
    //     instead of waiting out its verdict timeout.
    //

#if SAFEUPLOAD_STAGING_PROTOTYPE
    status = SafeUploadStagePrepareUnload();
    if (!NT_SUCCESS(status)) {
        if (!FlagOn( Flags, FLTFL_FILTER_UNLOAD_MANDATORY )) {
            SafeUploadStageFenceCancelUnload();
            return STATUS_FLT_DO_NOT_DETACH;
        }
    }
    SafeUploadStageFenceCommitUnload();
#endif

    SafeUploadCloseCommunicationPort();

    //
    //  2. Drain. Every later attempt to acquire rundown protection fails
    //     from here on, and this call returns once the last in-flight
    //     FltSendMessage has released it. Without this, an operation could
    //     still be touching the channel while it is being destroyed.
    //

    ExWaitForRundownProtectionRelease( &SafeUploadData.ChannelRundown );

#if SAFEUPLOAD_STAGING_PROTOTYPE
    SafeUploadStageStopWorker();
#endif

    //
    //  3. Unregister. FltUnregisterFilter waits for every in-flight
    //     callback to return, so once it completes no code of ours can run.
    //

    FltUnregisterFilter( SafeUploadData.Filter );
    SafeUploadData.Filter = NULL;

#if SAFEUPLOAD_STAGING_PROTOTYPE
    SafeUploadStageFree();
#endif

    //
    //  4. Release the policy. Last, because it can only be freed once no
    //     callback of ours can still be holding the snapshot - which is
    //     exactly what FltUnregisterFilter returning guarantees.
    //

    SafeUploadFreePolicy();
    SafeUploadFreeTaint();
    SafeUploadFreeOverrides();

    SafeUploadTrace( "unloaded\n" );

    return STATUS_SUCCESS;
}


NTSTATUS
SafeUploadInstanceSetup (
    _In_ PCFLT_RELATED_OBJECTS FltObjects,
    _In_ FLT_INSTANCE_SETUP_FLAGS Flags,
    _In_ DEVICE_TYPE VolumeDeviceType,
    _In_ FLT_FILESYSTEM_TYPE VolumeFilesystemType
    )
/*++

Routine Description:

    Called by the filter manager whenever it considers attaching an
    instance of this filter to a volume.

    IRQL: PASSIVE_LEVEL.

Arguments:

    FltObjects - The instance and volume being offered.

    Flags - Kind of attachment being made.

    VolumeDeviceType - DEVICE_TYPE of the volume.

    VolumeFilesystemType - File system formatted on the volume.

Return Value:

    STATUS_SUCCESS to attach, STATUS_FLT_DO_NOT_ATTACH to decline.

--*/
{
    SAFEUPLOAD_VOLUME_KIND volumeKind;
    NTSTATUS status;
#if SAFEUPLOAD_STAGING_PROTOTYPE
    BOOLEAN fenceSetupAdmitted = FALSE;
#endif

    UNREFERENCED_PARAMETER( VolumeFilesystemType );

    PAGED_CODE();

    //
    //  Network volumes are attached to, not refused. A network share is one
    //  of the destinations the policy monitors, so declining here would be
    //  a hole rather than an optimization.
    //

#if SAFEUPLOAD_STAGING_PROTOTYPE
    // Hold a nonblocking admission through the end of this callback. A voluntary unload cannot
    // commit while this setup is running. Demand-start tests also queue their existing refresh.
    if (!SafeUploadStageFenceSetupBegin()) {
        SafeUploadTrace("declining late volume attachment after unload commit\n");
        return STATUS_FLT_DO_NOT_ATTACH;
    }
    fenceSetupAdmitted = TRUE;
    if (!SafeUploadData.BootStartMode && !SafeUploadStageFenceQueueRefresh( FltObjects->Volume )) {
        SafeUploadTrace("declining late volume attachment: unload already committed\n");
        SafeUploadStageFenceSetupEnd();
        return STATUS_FLT_DO_NOT_ATTACH;
    }
    status = SafeUploadSetInstanceContext( FltObjects, VolumeDeviceType, Flags, &volumeKind );
#else
    status = SafeUploadSetInstanceContext( FltObjects, VolumeDeviceType, Flags, &volumeKind );
#endif

#if SAFEUPLOAD_STAGING_PROTOTYPE
    {
        LONG traceState = SafeUploadAdmissionTraceControlState;

        if ((traceState & 1) != 0 && SafeUploadStageAdmissionTraceBegin( traceState )) {
            SAFEUPLOAD_ADMISSION_TRACE_ENTRY entry;

            RtlZeroMemory( &entry, sizeof( entry ) );
            entry.EventKind = SAFEUPLOAD_ADMISSION_TRACE_EVENT_INSTANCE_SETUP;
            entry.ProcessId = (UINT32)(ULONG_PTR)PsGetCurrentProcessId();
            entry.Irql = KeGetCurrentIrql();
            entry.Instance = (UINT64)(ULONG_PTR)FltObjects->Instance;
            entry.AdmissionRecordState = 0;
            entry.SetupFlags = (UINT32) Flags;
            entry.VolumeKind = (UINT32) volumeKind;

            if (FlagOn( Flags, FLTFL_INSTANCE_SETUP_AUTOMATIC_ATTACHMENT )) {
                entry.AttachClass |= SAFEUPLOAD_ADMISSION_TRACE_ATTACH_AUTOMATIC;
            }
            if (FlagOn( Flags, FLTFL_INSTANCE_SETUP_MANUAL_ATTACHMENT )) {
                entry.AttachClass |= SAFEUPLOAD_ADMISSION_TRACE_ATTACH_MANUAL;
            }
            if (FlagOn( Flags, FLTFL_INSTANCE_SETUP_NEWLY_MOUNTED_VOLUME )) {
                entry.AttachClass |= SAFEUPLOAD_ADMISSION_TRACE_ATTACH_NEWLY_MOUNTED;
            }

            SafeUploadStageAdmissionTraceRecord( &entry );
            SafeUploadStageAdmissionTraceEnd();
        }
    }
#endif

    if (!NT_SUCCESS( status )) {
#if SAFEUPLOAD_STAGING_PROTOTYPE
        /* Keep the normal callbacks active. Every feature-build destination gate treats a missing
         * instance context as Unknown, which matches configured network/removable flags and explicit
         * prefixes; the fence admission above separately records supported-volume scan failures. */
        SafeUploadTrace( "instance context unavailable (status 0x%08X); retaining attachment with Unknown fallback\n",
                         status );
        volumeKind = SafeUploadVolumeUnknown;
#else
        /* Preserve the normal-build behavior; the feature build requires a usable context. */
        SafeUploadTrace( "instance classification context unavailable (status 0x%08X); attaching as unknown\n",
                         status );
        volumeKind = SafeUploadVolumeUnknown;
#endif
    }

    if (volumeKind == SafeUploadVolumeUnknown) {

        //
        //  Attach anyway.
        //
        //  An earlier version declined the attachment here, on the reasoning
        //  that a volume we cannot classify is a volume we cannot decide
        //  about. That reasoning was wrong in practice: it turns a
        //  recoverable, per-volume problem into a filter that is loaded,
        //  visible in "fltmc filters", and attached to nothing at all - the
        //  worst possible failure mode, because it looks like it is working.
        //
        //  In the feature build, policy gates conservatively treat Unknown as
        //  covered when removable/network destinations are enabled and still
        //  test explicit path prefixes. A missing context follows the same
        //  fallback while the normal callbacks remain attached.
        //

#if SAFEUPLOAD_STAGING_PROTOTYPE
        SafeUploadTrace( "volume not classified (status 0x%08X), attaching with conservative Unknown policy matching\n",
                         status );
#else
        SafeUploadTrace( "volume not classified (status 0x%08X), attaching as unknown\n", status );
#endif
    }
    else {

        SafeUploadTrace( "attached to volume, kind %s\n",
                         volumeKind == SafeUploadVolumeRemovable ? "removable" :
                         volumeKind == SafeUploadVolumeNetwork ? "network" : "fixed" );
    }

#if SAFEUPLOAD_STAGING_PROTOTYPE
    if (fenceSetupAdmitted) SafeUploadStageFenceSetupEnd();
#endif
    return STATUS_SUCCESS;
}


NTSTATUS
SafeUploadInstanceQueryTeardown (
    _In_ PCFLT_RELATED_OBJECTS FltObjects,
    _In_ FLT_INSTANCE_QUERY_TEARDOWN_FLAGS Flags
    )
/*++

Routine Description:

    Called when someone requests a manual detach of one of our instances
    ("fltmc detach"). The feature build refuses every manual detach because
    Filter Manager provides no reservation here that can exclude a later scan
    or attachment before teardown completes. This callback is not invoked for
    mandatory unload or volume dismount.

    IRQL: PASSIVE_LEVEL.

Arguments:

    FltObjects - Instance and volume being detached.

    Flags - Unused.

Return Value:

    STATUS_FLT_DO_NOT_DETACH - feature-build manual detach is disabled.
    STATUS_SUCCESS - normal-build behavior is unchanged.

--*/
{
    UNREFERENCED_PARAMETER( FltObjects );
    UNREFERENCED_PARAMETER( Flags );

    PAGED_CODE();

#if SAFEUPLOAD_STAGING_PROTOTYPE
    return STATUS_FLT_DO_NOT_DETACH;
#else
    return STATUS_SUCCESS;
#endif
}

///////////////////////////////////////////////////////////////////////////
//
//  Operation callbacks.
//
///////////////////////////////////////////////////////////////////////////

static
BOOLEAN
SafeUploadIsIgnoredProcess (
    _In_ ULONG ProcessId
    )
/*++

Routine Description:

    Decides whether I/O issued by a given process bypasses inspection
    entirely.

    IRQL: any. Touches no pageable data.

Arguments:

    ProcessId - PID of the process that issued the operation.

Return Value:

    TRUE if the operation must be allowed without asking user mode.

--*/
{
    //
    //  Idle and System drive paging, cache flushes and boot I/O. Blocking
    //  them - or merely making them wait on a user-mode process - is a
    //  reliable way to hang the machine.
    //

    if (ProcessId == SAFEUPLOAD_IDLE_PROCESS_ID ||
        ProcessId == SAFEUPLOAD_SYSTEM_PROCESS_ID) {

        return TRUE;
    }

    //
    //  The inspector's own I/O must never be sent to the inspector. It
    //  would be asked to arbitrate a file operation it is itself performing
    //  while it is blocked waiting to answer, which deadlocks the thread
    //  until the verdict timeout expires - on every single file it touches.
    //
    //  InspectorProcessId is 0 while nobody is connected, and PID 0 is
    //  already excluded above, so no extra guard is needed here.
    //

    if (ProcessId == SafeUploadData.InspectorProcessId) {

        return TRUE;
    }

    return FALSE;
}




static
NTSTATUS
SafeUploadCopyRequestPath (
    _Inout_ PFLT_CALLBACK_DATA Data,
    _Inout_ PSAFEUPLOAD_REQUEST Request
    )
/*++

Routine Description:

    Resolves the target file name and copies it into the request.

    FltMgr contract worth spelling out: the normalized name is the one form
    a filter can compare against without short-name or relative-open
    ambiguity, but it is not always available. In pre-create the file is not
    open yet, so producing it may require the file system to be queried, and
    the query is allowed to fail - a volume that is being dismounted, a name
    provider that is not ready, a create that will end in STATUS_REPARSE.
    When that happens the opened name is used instead: it is whatever the
    caller literally passed, which is still enough for the inspector to work
    with, and the request is flagged so user mode knows it is looking at a
    lower-quality name.

    IRQL: PASSIVE_LEVEL. FltGetFileNameInformation may issue I/O.

Arguments:

    Data - Parameters of the operation being inspected.

    Request - Request being built. Its Path, PathLength and Flags fields are
        filled in. The buffer is already zeroed by the caller, so the string
        is left NUL-terminated by construction.

Return Value:

    STATUS_SUCCESS when a name was obtained, otherwise the failing status.

--*/
{
    PFLT_FILE_NAME_INFORMATION nameInfo = NULL;
    NTSTATUS status;
    ULONG copyLength;

    PAGED_CODE();

    status = FltGetFileNameInformation( Data,
                                        FLT_FILE_NAME_NORMALIZED |
                                            FLT_FILE_NAME_QUERY_DEFAULT,
                                        &nameInfo );

    if (!NT_SUCCESS( status )) {

        status = FltGetFileNameInformation( Data,
                                            FLT_FILE_NAME_OPENED |
                                                FLT_FILE_NAME_QUERY_DEFAULT,
                                            &nameInfo );

        if (!NT_SUCCESS( status )) {

            return status;
        }

        SetFlag( Request->Flags, SAFEUPLOAD_REQUEST_FLAG_PATH_NOT_NORMALIZED );
    }

    copyLength = nameInfo->Name.Length;

    if (copyLength > SAFEUPLOAD_MAX_PATH_BYTES) {

        copyLength = SAFEUPLOAD_MAX_PATH_BYTES;
        SetFlag( Request->Flags, SAFEUPLOAD_REQUEST_FLAG_PATH_TRUNCATED );
    }

    if (copyLength != 0) {

        RtlCopyMemory( Request->Path, nameInfo->Name.Buffer, copyLength );
    }

    Request->PathLength = copyLength;

    //
    //  The reference taken by FltGetFileNameInformation is released on
    //  every path out of this routine, including the truncated one.
    //

    FltReleaseFileNameInformation( nameInfo );

    return STATUS_SUCCESS;
}


VOID
SafeUploadCopyRequestImageName (
    _In_ PFLT_CALLBACK_DATA Data,
    _Inout_ PSAFEUPLOAD_REQUEST Request
    )
/*++

Routine Description:

    Copies the file name of the requesting process image into the request,
    for example "notepad.exe".

    Best effort by design: this is context for the operator, not something
    a verdict depends on. Every failure leaves ImageName empty and the
    operation continues.

    IRQL: PASSIVE_LEVEL. SeLocateProcessImageName allocates and may block.

Arguments:

    Data - Parameters of the operation being inspected.

    Request - Request being built. ImageName, ImageNameLength and Flags may
        be updated.

Return Value:

    None.

--*/
{
    PEPROCESS process;
    PUNICODE_STRING imagePath = NULL;
    NTSTATUS status;
    ULONG charCount;
    ULONG index;
    ULONG firstChar;
    ULONG copyLength;

    PAGED_CODE();

    //
    //  FltGetRequestorProcess returns a pointer without taking a reference,
    //  which is safe here because the requesting process cannot go away
    //  while one of its threads is blocked inside this callback.
    //

    process = FltGetRequestorProcess( Data );

    if (process == NULL) {

        return;
    }

    //
    //  SeLocateProcessImageName allocates the string and transfers
    //  ownership to us; it has to be released with ExFreePool. It resolves
    //  the name from the process image section and issues no create of its
    //  own, so it cannot re-enter this filter.
    //

    status = SeLocateProcessImageName( process, &imagePath );

    if (!NT_SUCCESS( status ) || imagePath == NULL) {

        return;
    }

    //
    //  Keep only the last path component.
    //

    charCount = imagePath->Length / sizeof( WCHAR );
    firstChar = 0;

    for (index = 0; index < charCount; index += 1) {

        if (imagePath->Buffer[index] == L'\\') {

            firstChar = index + 1;
        }
    }

    copyLength = (charCount - firstChar) * sizeof( WCHAR );

    if (copyLength > SAFEUPLOAD_MAX_IMAGE_NAME_BYTES) {

        copyLength = SAFEUPLOAD_MAX_IMAGE_NAME_BYTES;
        SetFlag( Request->Flags, SAFEUPLOAD_REQUEST_FLAG_IMAGE_NAME_TRUNCATED );
    }

    if (copyLength != 0) {

        RtlCopyMemory( Request->ImageName,
                       &imagePath->Buffer[firstChar],
                       copyLength );

        Request->ImageNameLength = copyLength;
    }

    ExFreePool( imagePath );
}


static
BOOLEAN
SafeUploadEvaluate (
    _Inout_ PFLT_CALLBACK_DATA Data,
    _In_ SAFEUPLOAD_VOLUME_KIND VolumeKind,
    _Out_ PUINT32 ScopeFlags,
    _Out_ PUINT32 Verdict
    )
/*++

Routine Description:

    Works out whether an operation is in scope and, if it is, asks user mode
    for a verdict.

    This is the expensive path: it resolves a name, may resolve a process
    image, and may block on a round trip. Everything above it exists to keep
    operations from reaching it, and the stream context exists to keep the
    same file from reaching it twice.

    IRQL: PASSIVE_LEVEL.

Arguments:

    Data - Parameters of the operation.

    VolumeKind - Classification of the volume, from the instance context.

    ScopeFlags - Receives SAFEUPLOAD_REQUEST_FLAG_SCOPE_*, or zero when the
        operation is out of scope. Zero is a useful answer worth caching: it
        means this file never has to be evaluated again.

    Verdict - Receives SAFEUPLOAD_VERDICT_*. Always set to ALLOW before
        anything can fail, so no error path leaves it undefined (RN-013).

Return Value:

    TRUE when Verdict is a checked answer safe to cache - the operation was
    out of scope or user mode actually replied.
    FALSE when Verdict is ALLOW only because user mode could not be reached
    (allocation failure, name resolution failure, or a fail-open inside
    SafeUploadRequestVerdict): the caller must treat this as unchecked, not
    cache it, and count it as AllowedWithoutInspection.

--*/
{
    PSAFEUPLOAD_EXCHANGE exchange;
    UNICODE_STRING normalizedPath;
    UNICODE_STRING imageName;
    NTSTATUS status;
    BOOLEAN answered;

    PAGED_CODE();

    *ScopeFlags = 0;
    *Verdict = SAFEUPLOAD_VERDICT_ALLOW;

    exchange = (PSAFEUPLOAD_EXCHANGE) ExAllocatePool2( POOL_FLAG_NON_PAGED,
                                                       sizeof( SAFEUPLOAD_EXCHANGE ),
                                                       SAFEUPLOAD_POOL_TAG );

    if (exchange == NULL) {

        //
        //  Could not even build the request. Same fail-open reasoning as a
        //  timeout: RN-013 says allow, and this was never a checked verdict.
        //

        SafeUploadCount( AllowedWithoutInspection );
        return FALSE;
    }

    exchange->Request.Version = SAFEUPLOAD_PROTOCOL_VERSION;
    exchange->Request.StructSize = sizeof( SAFEUPLOAD_REQUEST );
    exchange->Request.RequestId =
        (UINT64) InterlockedIncrement64( &SafeUploadData.NextRequestId );
    exchange->Request.Operation = SAFEUPLOAD_OPERATION_CREATE;
    exchange->Request.RequestorProcessId = FltGetRequestorProcessId( Data );

    status = SafeUploadCopyRequestPath( Data, &exchange->Request );

    if (!NT_SUCCESS( status )) {

        //
        //  Could not even resolve the name being operated on. Same
        //  fail-open reasoning as a timeout: never a checked verdict.
        //

        SafeUploadCount( AllowedWithoutInspection );
        ExFreePoolWithTag( exchange, SAFEUPLOAD_POOL_TAG );
        return FALSE;
    }

    SafeUploadCount( ScopeEvaluations );

    normalizedPath.Buffer = exchange->Request.Path;
    normalizedPath.Length = (USHORT) exchange->Request.PathLength;
    normalizedPath.MaximumLength = normalizedPath.Length;

    if (SafeUploadPolicyMatchesDestination( VolumeKind, &normalizedPath )) {

        SetFlag( exchange->Request.Flags, SAFEUPLOAD_REQUEST_FLAG_SCOPE_DESTINATION );
    }

    // Only a read open may classify a source and mark its process. A
    // write-only open of a sensitive file must not taint the writer.
    if (Data->Iopb->Parameters.Create.SecurityContext != NULL &&
        FlagOn( Data->Iopb->Parameters.Create.SecurityContext->DesiredAccess,
                FILE_READ_DATA ) &&
        SafeUploadPolicyMatchesSource( &normalizedPath )) {

        SetFlag( exchange->Request.Flags, SAFEUPLOAD_REQUEST_FLAG_SCOPE_SOURCE );
    }

    *ScopeFlags = exchange->Request.Flags &
                  (SAFEUPLOAD_REQUEST_FLAG_SCOPE_DESTINATION |
                   SAFEUPLOAD_REQUEST_FLAG_SCOPE_SOURCE);

    if (*ScopeFlags == 0) {

        //
        //  Out of scope is a real, checked answer - just not one that
        //  needed a round trip to reach.
        //

        ExFreePoolWithTag( exchange, SAFEUPLOAD_POOL_TAG );
        return TRUE;
    }

    SafeUploadCopyRequestImageName( Data, &exchange->Request );

    //
    //  RN-014. Checked here rather than earlier because the image name is
    //  only known once it has been resolved.
    //

    if (exchange->Request.ImageNameLength != 0) {

        imageName.Buffer = exchange->Request.ImageName;
        imageName.Length = (USHORT) exchange->Request.ImageNameLength;
        imageName.MaximumLength = imageName.Length;

        if (SafeUploadPolicyExcludesImage( &imageName )) {

            //
            //  An image exclusion belongs to this requestor, not the file.
            //  Another process still needs its own inspection.
            //

            *ScopeFlags = 0;
            ExFreePoolWithTag( exchange, SAFEUPLOAD_POOL_TAG );
            return FALSE;
        }
    }

    SafeUploadCount( UserModeRoundTrips );

    (VOID) SafeUploadRequestVerdict( exchange, Verdict, &answered );

    if (!answered) {

        SafeUploadCount( AllowedWithoutInspection );
    }

    ExFreePoolWithTag( exchange, SAFEUPLOAD_POOL_TAG );

    return answered;
}


static
BOOLEAN
SafeUploadReadFileStamp (
    _In_ PCFLT_RELATED_OBJECTS FltObjects,
    _Out_ PLARGE_INTEGER FileSize,
    _Out_ PLARGE_INTEGER LastWriteTime
    )
/*++

Routine Description:

    Reads the size and last write time of the file behind a completed
    create, to stamp a cached verdict with.

    The stamp is what makes the cache safe against changes this driver never
    observed - a volume modified while the filter was unloaded, for
    instance. The Dirty flag covers the changes it did observe.

    IRQL: PASSIVE_LEVEL.

Arguments:

    FltObjects - Objects for the create that just completed.

    FileSize, LastWriteTime - Receive the stamp, or zero when it could not
        be read. A failed query is distinct from a confirmed empty file.

Return Value:

    TRUE only when the file size and time were read successfully.

--*/
{
    FILE_NETWORK_OPEN_INFORMATION information;
    NTSTATUS status;

    PAGED_CODE();

    FileSize->QuadPart = 0;
    LastWriteTime->QuadPart = 0;

    status = FltQueryInformationFile( FltObjects->Instance,
                                      FltObjects->FileObject,
                                      &information,
                                      sizeof( information ),
                                      FileNetworkOpenInformation,
                                      NULL );

    if (NT_SUCCESS( status )) {

        *FileSize = information.EndOfFile;
        *LastWriteTime = information.LastWriteTime;
        return TRUE;
    }

    return FALSE;
}


static
BOOLEAN
SafeUploadOverrideCovers (
    _Inout_ PFLT_CALLBACK_DATA Data,
    _In_ ULONG ProcessId
    )
/*++

Routine Description:

    Whether a user-granted exception covers this create.

    Resolves the opened name a second time, and that is deliberate: this
    runs only on the path that is about to refuse, which is rare. Threading
    the name through the cheap gates would put the cost on every operation
    to save it on almost none.

    IRQL: PASSIVE_LEVEL.

Return Value:

    TRUE when an exception covered the operation - and it is consumed.

--*/
{
    PFLT_FILE_NAME_INFORMATION nameInfo = NULL;
    BOOLEAN covered;
    NTSTATUS status;

    PAGED_CODE();

    if (!SafeUploadPolicyAllowsOverride()) {

        return FALSE;
    }

    status = FltGetFileNameInformation( Data,
                                        FLT_FILE_NAME_OPENED |
                                            FLT_FILE_NAME_QUERY_DEFAULT,
                                        &nameInfo );

    if (!NT_SUCCESS( status )) {
#if SAFEUPLOAD_STAGING_PROTOTYPE
        /* Name-query failure is never an override grant. */
        return FALSE;
#else
        return FALSE;
#endif
    }

    covered = SafeUploadConsumeOverride( ProcessId, &nameInfo->Name );

    FltReleaseFileNameInformation( nameInfo );

    return covered;
}


static
BOOLEAN
SafeUploadIsMonitoredDestination (
    _Inout_ PFLT_CALLBACK_DATA Data,
    _In_ SAFEUPLOAD_VOLUME_KIND VolumeKind
    )
/*++

Routine Description:

    Whether a create is heading for a monitored destination, answered as
    cheaply as the policy allows.

    Removable media and network shares are settled by the volume kind alone,
    with no name at all - which is the case that matters most, because a pen
    drive is where a refusal has to leave nothing behind.

    Only a fixed volume needs a name, and only then is one resolved. The
    caller checks process taint first precisely so that this cost is paid
    for tainted processes, which are rare, rather than for every write.

    The opened name is used rather than the normalized one: normalization
    can fail in pre-create, and the filter manager returns opened names in
    device form (\Device\HarddiskVolumeN\...), which is what the policy
    prefixes are written in. A short name that fails to match means an
    operation goes uninspected, never wrongly refused.

    IRQL: PASSIVE_LEVEL.

Arguments:

    Data - Parameters of the create.

    VolumeKind - Classification from the instance context.

Return Value:

    TRUE when the destination is monitored.

--*/
{
    PFLT_FILE_NAME_INFORMATION nameInfo = NULL;
    BOOLEAN monitored;
    NTSTATUS status;

    PAGED_CODE();

    if (SafeUploadPolicyMatchesDestination( VolumeKind, NULL )) {

        return TRUE;
    }

    status = FltGetFileNameInformation( Data,
                                        FLT_FILE_NAME_OPENED |
                                            FLT_FILE_NAME_QUERY_DEFAULT,
                                        &nameInfo );

    if (!NT_SUCCESS( status )) {
#if SAFEUPLOAD_STAGING_PROTOTYPE
        /* Unknown classification plus an unresolved name cannot prove that an explicit prefix is
         * outside scope. Broad removable/network flags were checked above; conservatively cover
         * prefix-only policies here as well. */
        if (VolumeKind == SafeUploadVolumeUnknown) {
            return TRUE;
        }
#endif
        return FALSE;
    }

    monitored = SafeUploadPolicyMatchesDestination( VolumeKind, &nameInfo->Name );

    FltReleaseFileNameInformation( nameInfo );

    return monitored;
}





static BOOLEAN SafeUploadCreateIsWriter(_In_ PFLT_CALLBACK_DATA Data)
{
    PIO_SECURITY_CONTEXT security = Data->Iopb->Parameters.Create.SecurityContext;
    ULONG disposition = Data->Iopb->Parameters.Create.Options >> 24;
    if (security == NULL) return FALSE;
    return BooleanFlagOn(security->DesiredAccess,
            FILE_WRITE_DATA | FILE_APPEND_DATA | FILE_WRITE_ATTRIBUTES | FILE_WRITE_EA |
            FILE_DELETE_CHILD | DELETE | WRITE_DAC | WRITE_OWNER | MAXIMUM_ALLOWED |
            GENERIC_WRITE | GENERIC_ALL) ||
        FlagOn(Data->Iopb->Parameters.Create.Options, FILE_DELETE_ON_CLOSE) ||
        disposition == FILE_CREATE || disposition == FILE_SUPERSEDE ||
        disposition == FILE_OVERWRITE || disposition == FILE_OVERWRITE_IF;
}

/* The connected-port bit alone is not authorization: only an accepted SET_POLICY
 * from the authenticated service enables protected writes. */
static BOOLEAN SafeUploadFailClosedProtectedCreate(_Inout_ PFLT_CALLBACK_DATA Data,
    _In_ PCFLT_RELATED_OBJECTS FltObjects)
{
    PFLT_FILE_NAME_INFORMATION name = NULL;
    PSAFEUPLOAD_INSTANCE_CONTEXT instanceContext = NULL;
    SAFEUPLOAD_VOLUME_KIND kind = SafeUploadVolumeUnknown;
    BOOLEAN protectedName = FALSE;
    NTSTATUS status;

    PAGED_CODE();
    if (!SafeUploadCreateIsWriter(Data) || Data->Iopb->TargetFileObject == NULL) return FALSE;

    if (NT_SUCCESS(FltGetInstanceContext(FltObjects->Instance,
            (PFLT_CONTEXT *)&instanceContext))) {
        kind = instanceContext->VolumeKind;
        FltReleaseContext(instanceContext);
    }

    /* An open that begins while the authenticated service is connected on a
     * trusted instance keeps the existing policy path. With no destination
     * scopes there is no reason to normalize every unrelated boot write. */
    if ((SafeUploadIsAuthenticatedClient() && SafeUploadInstanceTrustGateSatisfied(FltObjects->Instance)) ||
        !SafeUploadPolicyHasDestinationScopes(kind)) return FALSE;

    status = FltGetFileNameInformation(Data,
        FLT_FILE_NAME_NORMALIZED | FLT_FILE_NAME_QUERY_DEFAULT, &name);
    if (NT_SUCCESS(status) && name != NULL && NT_SUCCESS(FltParseFileNameInformation(name))) {
        protectedName = SafeUploadPolicyMatchesDestination(kind, &name->Name);
    } else {
        /* A volume-kind scope remains identifiable without a path. A
         * path-prefix scope is not widened to the rest of a fixed volume. */
        protectedName = SafeUploadPolicyMatchesDestination(kind, NULL);
    }
    if (name != NULL) FltReleaseFileNameInformation(name);

    return protectedName && (!SafeUploadInstanceTrustGateSatisfied(FltObjects->Instance) ||
        !SafeUploadIsAuthenticatedClient());
}

static FLT_PREOP_CALLBACK_STATUS SafeUploadPreAcquireSection(_Inout_ PFLT_CALLBACK_DATA Data,
    _In_ PCFLT_RELATED_OBJECTS FltObjects,
    _Flt_CompletionContext_Outptr_ PVOID *CompletionContext)
{
    PFLT_FILE_NAME_INFORMATION name = NULL;
    PSAFEUPLOAD_INSTANCE_CONTEXT instanceContext = NULL;
    SAFEUPLOAD_VOLUME_KIND kind = SafeUploadVolumeUnknown;
    BOOLEAN protectedName = FALSE;
    NTSTATUS status;

    *CompletionContext = NULL;
    PAGED_CODE();
    if (Data->Iopb->Parameters.AcquireForSectionSynchronization.SyncType != SyncTypeCreateSection ||
        !FlagOn(Data->Iopb->Parameters.AcquireForSectionSynchronization.PageProtection,
            PAGE_READWRITE | PAGE_EXECUTE_READWRITE) ||
        FlagOn(Data->Iopb->Parameters.AcquireForSectionSynchronization.AllocationAttributes, SEC_IMAGE)) {
        return FLT_PREOP_SUCCESS_NO_CALLBACK;
    }

    if (NT_SUCCESS(FltGetInstanceContext(FltObjects->Instance,
            (PFLT_CONTEXT *)&instanceContext))) {
        kind = instanceContext->VolumeKind;
        FltReleaseContext(instanceContext);
    }
    if ((SafeUploadIsAuthenticatedClient() && SafeUploadInstanceTrustGateSatisfied(FltObjects->Instance)) ||
        !SafeUploadPolicyHasDestinationScopes(kind)) return FLT_PREOP_SUCCESS_NO_CALLBACK;
    status = FltGetFileNameInformation(Data,
        FLT_FILE_NAME_NORMALIZED | FLT_FILE_NAME_QUERY_DEFAULT, &name);
    if (NT_SUCCESS(status) && name != NULL && NT_SUCCESS(FltParseFileNameInformation(name)))
        protectedName = SafeUploadPolicyMatchesDestination(kind, &name->Name);
    else
        protectedName = SafeUploadPolicyMatchesDestination(kind, NULL);
    if (name != NULL) FltReleaseFileNameInformation(name);

    if (protectedName && (!SafeUploadInstanceTrustGateSatisfied(FltObjects->Instance) ||
        !SafeUploadIsAuthenticatedClient())) {
        Data->IoStatus.Status = STATUS_ACCESS_DENIED;
        Data->IoStatus.Information = 0;
        return FLT_PREOP_COMPLETE;
    }
    return FLT_PREOP_SUCCESS_NO_CALLBACK;
}

FLT_PREOP_CALLBACK_STATUS
SafeUploadPreCreate (
    _Inout_ PFLT_CALLBACK_DATA Data,
    _In_ PCFLT_RELATED_OBJECTS FltObjects,
    _Flt_CompletionContext_Outptr_ PVOID *CompletionContext
    )
/*++

Routine Description:

    Pre-operation callback for IRP_MJ_CREATE.

    This routine no longer decides anything. It runs the gates that cost
    nothing but comparisons and, for what survives them, asks for a
    post-operation callback - because the stream context that caches
    verdicts does not exist until the create has completed, and a cache that
    cannot be consulted is not a cache.

    IRQL: PASSIVE_LEVEL, guaranteed by the filter manager for IRP_MJ_CREATE,
    which is why this may live in a pageable section.

    FltObjects->FileObject is NULL here: in pre-create the file object is
    not yet associated with the instance, so the target has to be read from
    Data->Iopb->TargetFileObject.

Arguments:

    Data - Parameters of the operation.

    FltObjects - Objects affected by the operation.

    CompletionContext - Receives the volume classification, so post-create
        does not have to look the instance context up again.

Return Value:

    FLT_PREOP_SUCCESS_WITH_CALLBACK when the operation deserves a closer
    look, FLT_PREOP_SUCCESS_NO_CALLBACK otherwise.

--*/
{
    PFILE_OBJECT targetFileObject;
    PIO_SECURITY_CONTEXT securityContext;
    PSAFEUPLOAD_INSTANCE_CONTEXT instanceContext = NULL;
    SAFEUPLOAD_VOLUME_KIND volumeKind;
    BOOLEAN monitoredExtension;
    BOOLEAN taintedWriter = FALSE;
    NTSTATUS status;


    *CompletionContext = NULL;

    PAGED_CODE();

    if (FltObjects->Transaction != NULL &&
        SafeUploadStageTxfCreateMustRefuse(Data, FltObjects)) {
        SafeUploadStageTxfRecordRefused();
        Data->IoStatus.Status = STATUS_ACCESS_DENIED;
        Data->IoStatus.Information = 0;
        return FLT_PREOP_COMPLETE;
    }

    SafeUploadCount( CreatesSeen );



    //
    targetFileObject = Data->Iopb->TargetFileObject;

    if (targetFileObject == NULL) {

        return FLT_PREOP_SUCCESS_NO_CALLBACK;
    }

    if (SafeUploadFailClosedProtectedCreate(Data, FltObjects)) {
        Data->IoStatus.Status = STATUS_ACCESS_DENIED;
        Data->IoStatus.Information = 0;
        return FLT_PREOP_COMPLETE;
    }

    /* Reads and writes outside protected scopes keep the existing no-port
     * behavior. Recheck after the initial fail-closed probe so a disconnect
     * between the two checks cannot turn the create into a no-port allow. */
    if (!SafeUploadIsAuthenticatedClient()) {
        if (SafeUploadFailClosedProtectedCreate(Data, FltObjects)) {
            Data->IoStatus.Status = STATUS_ACCESS_DENIED;
            Data->IoStatus.Information = 0;
            return FLT_PREOP_COMPLETE;
        }
        return FLT_PREOP_SUCCESS_NO_CALLBACK;
    }

    //
    //  Volume opens (opening \Device\HarddiskVolumeN itself). They carry an
    //  empty name and no related file object. There is no file path to hand
    //  to the inspector, and denying one breaks volume management.
    //

    if (targetFileObject->FileName.Length == 0 &&
        targetFileObject->RelatedFileObject == NULL) {

        return FLT_PREOP_SUCCESS_NO_CALLBACK;
    }

    //
    //  Directory opens. FILE_DIRECTORY_FILE lives in the low 24 bits of
    //  Options; the top byte holds the create disposition.
    //

    if (FlagOn( Data->Iopb->Parameters.Create.Options, FILE_DIRECTORY_FILE )) {

        return FLT_PREOP_SUCCESS_NO_CALLBACK;
    }

    //
    //  The single most effective gate in the driver.
    //
    //  An operation that does not ask for the file's data cannot leak it,
    //  and the overwhelming majority of creates on a running Windows ask for
    //  nothing more than attributes or metadata - stat calls, directory
    //  enumeration follow-ups, delete checks, sharing probes. All of them
    //  end here, in two bit tests, before any context lookup, any name
    //  resolution and any allocation.
    //

    securityContext = Data->Iopb->Parameters.Create.SecurityContext;

    if (securityContext == NULL ||
        !FlagOn( securityContext->DesiredAccess,
                 FILE_READ_DATA | FILE_WRITE_DATA | FILE_APPEND_DATA )) {

        return FLT_PREOP_SUCCESS_NO_CALLBACK;
    }

    if (SafeUploadIsIgnoredProcess( FltGetRequestorProcessId( Data ) )) {

        return FLT_PREOP_SUCCESS_NO_CALLBACK;
    }

    monitoredExtension = SafeUploadPolicyMatchesExtension( &targetFileObject->FileName );

    if (!monitoredExtension) {

        // Keep the cheap exit for ordinary files. Only an unmonitored
        // extension written by an already tainted process can reach the
        // destination gate below.
        taintedWriter = (BOOLEAN)
            (FlagOn( securityContext->DesiredAccess,
                     FILE_WRITE_DATA | FILE_APPEND_DATA ) &&
             SafeUploadIsProcessTainted( FltGetRequestorProcessId( Data ) ));

        if (!taintedWriter) {
            return FLT_PREOP_SUCCESS_NO_CALLBACK;
        }
    }

    //
    //  The volume kind was worked out once, when this instance attached.
    //  Reading it back is a context lookup; recomputing it would be a
    //  FltGetVolumeProperties call on every create.
    //

    status = FltGetInstanceContext( FltObjects->Instance,
                                    (PFLT_CONTEXT *) &instanceContext );

    if (!NT_SUCCESS( status )) {
#if SAFEUPLOAD_STAGING_PROTOTYPE
        /* A missing instance context is not proof that this is an unmonitored volume. */
        volumeKind = SafeUploadVolumeUnknown;
#else
        return FLT_PREOP_SUCCESS_NO_CALLBACK;
#endif
    } else {
        volumeKind = instanceContext->VolumeKind;
        FltReleaseContext( instanceContext );
    }

    SafeUploadCount( CreatesPastCheapGates );

    //
    //  The zero-byte refusal.
    //
    //  A process that has handled sensitive content may not open a
    //  monitored destination for writing. This is decided here, in
    //  pre-create, and it asks user mode nothing: the expensive question
    //  was answered when the source was opened, and its answer is a hash
    //  lookup away. Refusing here means the create never happens - no file
    //  created, nothing truncated, nothing left behind.
    //
    //  Taint is checked before the destination, and the order is the point:
    //  the taint lookup costs nothing, while deciding whether a fixed
    //  volume path is monitored may cost a name resolution. Paying that
    //  only for tainted processes keeps it off the common path.
    //

    if (FlagOn( securityContext->DesiredAccess,
                FILE_WRITE_DATA | FILE_APPEND_DATA ) &&
        (taintedWriter ||
         SafeUploadIsProcessTainted( FltGetRequestorProcessId( Data ) )) &&
        SafeUploadIsMonitoredDestination( Data, volumeKind )) {

        //
        //  Em modo auditoria a escrita segue, contada como o que teria
        //  sido negado. E o unico jeito de conhecer o custo do bloqueio
        //  antes de liga-lo, que e como todo DLP de mercado e implantado.
        //

        //
        //  Excecao antes de negar, e so aqui: este e o caminho frio, o unico
        //  que ja decidiu recusar.
        //

        if (SafeUploadOverrideCovers( Data, FltGetRequestorProcessId( Data ) )) {

            *CompletionContext = (PVOID) (ULONG_PTR)
                ((ULONG) volumeKind | SAFEUPLOAD_POSTCREATE_OVERRIDE);

            return FLT_PREOP_SUCCESS_WITH_CALLBACK;
        }

        if (SafeUploadPolicyAuditOnly()) {

            SafeUploadCount( WouldHaveDenied );

            SafeUploadTrace( "AUDITORIA: escrita seria negada, processo %lu marcado\n",
                             FltGetRequestorProcessId( Data ) );

        } else {

            SafeUploadCount( DeniedPreCreate );

            SafeUploadTrace( "escrita negada: processo %lu marcado\n",
                             FltGetRequestorProcessId( Data ) );

            Data->IoStatus.Status = STATUS_ACCESS_DENIED;
            Data->IoStatus.Information = 0;

            return FLT_PREOP_COMPLETE;
        }
    }

    // Content inspection is limited to configured formats. Destination
    // blocking above is not: renaming or writing a .bin file into a cloud
    // folder must not bypass a tainted process's egress restriction.
    if (!monitoredExtension) {

        return FLT_PREOP_SUCCESS_NO_CALLBACK;
    }

    *CompletionContext = (PVOID) (ULONG_PTR) volumeKind;

    return FLT_PREOP_SUCCESS_WITH_CALLBACK;
}


FLT_POSTOP_CALLBACK_STATUS
SafeUploadPostCreate (
    _Inout_ PFLT_CALLBACK_DATA Data,
    _In_ PCFLT_RELATED_OBJECTS FltObjects,
    _In_opt_ PVOID CompletionContext,
    _In_ FLT_POST_OPERATION_FLAGS Flags
    )
/*++

Routine Description:

    Post-operation callback for IRP_MJ_CREATE, and the only place that asks
    user mode anything.

    Here the file exists, the stream context is available, and a verdict can
    be cached against the file rather than recomputed per open. That cache is
    the property the whole design rests on: one round trip per file version,
    not one per operation and not one per handle.

    Denial here is FltCancelFileOpen rather than a failed pre-operation. The
    create has already succeeded, so undoing it is the only way to refuse -
    which is what the WDK scanner sample does, for the same reason.

    IRQL: PASSIVE_LEVEL for IRP_MJ_CREATE.

Arguments:

    Data - Parameters of the operation.

    FltObjects - Objects affected by the operation.

    CompletionContext - The volume classification, from pre-create.

    Flags - FLTFL_POST_OPERATION_DRAINING when the filter is being torn
        down.

Return Value:

    FLT_POSTOP_FINISHED_PROCESSING.

--*/
{
    PSAFEUPLOAD_STREAM_CONTEXT streamContext = NULL;
    SAFEUPLOAD_VOLUME_KIND volumeKind;
    BOOLEAN overrideGranted;
    LARGE_INTEGER fileSize;
    LARGE_INTEGER lastWriteTime;
    UINT32 scopeFlags = 0;
    UINT32 verdict = SAFEUPLOAD_VERDICT_ALLOW;
    BOOLEAN answered = FALSE;
    BOOLEAN inspected;
    BOOLEAN stampKnown;
    BOOLEAN cacheEligible;
    LONG policyGeneration;
    LONG currentGeneration;
    NTSTATUS status;

    PAGED_CODE();



    volumeKind = (SAFEUPLOAD_VOLUME_KIND)
        ((ULONG_PTR) CompletionContext & ~SAFEUPLOAD_POSTCREATE_OVERRIDE);
    overrideGranted = (BOOLEAN)
        (((ULONG_PTR) CompletionContext & SAFEUPLOAD_POSTCREATE_OVERRIDE) != 0);

    //
    //  Draining means the filter is going away, and no callback of ours
    //  should start new work.
    //

    if (FlagOn( Flags, FLTFL_POST_OPERATION_DRAINING )) {

        return FLT_POSTOP_FINISHED_PROCESSING;
    }

    //
    //  A create that failed anyway has nothing to arbitrate, and a reparse
    //  comes back around as another create.
    //

    if (!NT_SUCCESS( Data->IoStatus.Status ) ||
        Data->IoStatus.Status == STATUS_REPARSE) {

        return FLT_POSTOP_FINISHED_PROCESSING;
    }

    // A justified create can cover an extension outside the inspection
    // list. It still needs a handle marker so the following write does not
    // consume a second grant or get denied by the write callback.
    if (overrideGranted &&
        !SafeUploadPolicyMatchesExtension( &FltObjects->FileObject->FileName )) {

        if (FltObjects->FileObject->WriteAccess) {
            (VOID) SafeUploadMarkHandleForWrite( FltObjects, TRUE );
        }

        return FLT_POSTOP_FINISHED_PROCESSING;
    }

    stampKnown = SafeUploadReadFileStamp( FltObjects, &fileSize, &lastWriteTime );
    policyGeneration = SafeUploadCurrentPolicyGeneration();

    // Source classification depends on the access requested for this open.
    // A write-only open must not cache an out-of-scope result that a later
    // reader can reuse, nor inherit a reader's sensitive source verdict.
    cacheEligible = (BOOLEAN)
        (Data->Iopb->Parameters.Create.SecurityContext != NULL &&
         FlagOn( Data->Iopb->Parameters.Create.SecurityContext->DesiredAccess,
                 FILE_READ_DATA ) &&
         !SafeUploadPolicyClassifiesAllSources());

    // A newly created or truncated file has no content to classify yet.
    // Reading it from user mode may fail on the just-opened write handle;
    // treating that failure as sensitive taints a clean writer. Keep the
    // write-handle marker so cleanup dirties any previous stream verdict.
    if (stampKnown && fileSize.QuadPart == 0) {

        if (FltObjects->FileObject->WriteAccess) {
            (VOID) SafeUploadMarkHandleForWrite( FltObjects, overrideGranted );
        }

        return FLT_POSTOP_FINISHED_PROCESSING;
    }

    status = STATUS_SUCCESS;
    if (cacheEligible) {
        status = SafeUploadGetOrCreateStreamContext( FltObjects,
                                                     FltObjects->FileObject,
                                                     &streamContext );
    }

    if (NT_SUCCESS( status ) && cacheEligible) {

        FltAcquirePushLockShared( &streamContext->Lock );

        if (streamContext->ScopeEvaluated &&
            streamContext->PolicyGeneration == policyGeneration) {

            if (streamContext->ScopeFlags == 0) {

                //
                //  Known to be out of scope. This is the entry that pays for
                //  itself the most: it skips a name resolution on every
                //  later open of a file the policy does not care about.
                //

                scopeFlags = 0;
                answered = TRUE;

            } else if (streamContext->VerdictValid &&
                       !streamContext->Dirty &&
                       streamContext->FileSize.QuadPart == fileSize.QuadPart &&
                       streamContext->LastWriteTime.QuadPart == lastWriteTime.QuadPart) {

                scopeFlags = streamContext->ScopeFlags;
                verdict = streamContext->Verdict;
                answered = TRUE;
            }
        }

        FltReleasePushLock( &streamContext->Lock );
    }

    currentGeneration = SafeUploadCurrentPolicyGeneration();
    if (currentGeneration != policyGeneration) {
        policyGeneration = currentGeneration;
        answered = FALSE;
        scopeFlags = 0;
        verdict = SAFEUPLOAD_VERDICT_ALLOW;
    }

    if (answered) {
        SafeUploadCount( CacheHits );
    }

    if (!answered) {

        inspected = SafeUploadEvaluate( Data, volumeKind, &scopeFlags, &verdict );

        if (streamContext != NULL && cacheEligible) {

            FltAcquirePushLockExclusive( &streamContext->Lock );

            streamContext->ScopeEvaluated = inspected;
            streamContext->PolicyGeneration = policyGeneration;
            streamContext->ScopeFlags = scopeFlags;
            streamContext->Verdict = verdict;

            //
            //  A verdict earns a place in the cache only when it was
            //  actually checked. An unchecked ALLOW (timeout, no port,
            //  allocation failure) must be retried on the next open, not
            //  reused as if user mode had cleared the file - otherwise a
            //  single failure turns into a standing exemption that lasts
            //  until the file's bytes change.
            //

            streamContext->VerdictValid = (BOOLEAN) (scopeFlags != 0 && inspected);
            streamContext->Dirty = FALSE;
            streamContext->FileSize = fileSize;
            streamContext->LastWriteTime = lastWriteTime;

            FltReleasePushLock( &streamContext->Lock );
        }
    }

    if (streamContext != NULL) {

        FltReleaseContext( streamContext );
    }

    if (scopeFlags == 0 && !overrideGranted) {

        return FLT_POSTOP_FINISHED_PROCESSING;
    }

    //
    //  A handle opened for write invalidates the cached verdict when it
    //  closes, because the content may have changed underneath us.
    //

    if (FltObjects->FileObject->WriteAccess) {

        (VOID) SafeUploadMarkHandleForWrite( FltObjects, overrideGranted );
    }

    if (verdict == SAFEUPLOAD_VERDICT_DENY) {

        //
        //  Sensitive content reached this process. The read itself is
        //  allowed - the user has every right to open their own document -
        //  and what is recorded is that this process now carries it.
        //

        if (FlagOn( scopeFlags, SAFEUPLOAD_REQUEST_FLAG_SCOPE_SOURCE )) {

            SafeUploadTaintProcess( FltGetRequestorProcessId( Data ), 1 );
        }

        //
        //  A file already on its way out is refused outright. This is the
        //  weaker refusal of the two: FltCancelFileOpen undoes the open, so
        //  no content is ever readable, but it does not undo whatever the
        //  create itself did - a file may have been created or truncated
        //  before this callback ran. The strong refusal is the pre-create
        //  one above.
        //

        if (FlagOn( scopeFlags, SAFEUPLOAD_REQUEST_FLAG_SCOPE_DESTINATION ) &&
            !overrideGranted) {

            //
            //  Excecao antes de cancelar, pelo mesmo motivo do pre-create:
            //  este e o caminho que ja decidiu recusar.
            //

            if (SafeUploadOverrideCovers( Data, FltGetRequestorProcessId( Data ) )) {

                if (FltObjects->FileObject->WriteAccess) {
                    (VOID) SafeUploadMarkHandleForWrite( FltObjects, TRUE );
                }

                return FLT_POSTOP_FINISHED_PROCESSING;
            }

            if (SafeUploadPolicyAuditOnly()) {

                SafeUploadCount( WouldHaveDenied );

            } else {

                SafeUploadCount( DeniedPostCreate );

                FltCancelFileOpen( FltObjects->Instance, FltObjects->FileObject );

                Data->IoStatus.Status = STATUS_ACCESS_DENIED;
                Data->IoStatus.Information = 0;
            }
        }
    }

    return FLT_POSTOP_FINISHED_PROCESSING;
}


FLT_PREOP_CALLBACK_STATUS
SafeUploadPreWrite (
    _Inout_ PFLT_CALLBACK_DATA Data,
    _In_ PCFLT_RELATED_OBJECTS FltObjects,
    _Flt_CompletionContext_Outptr_ PVOID *CompletionContext
    )
/*++

Routine Description:

    Closes the already-open-handle gap. A process can open a destination
    before reading sensitive content; the create gate cannot know that it
    will become tainted later. Only a tainted process reaches the destination
    check, so ordinary writes do no name lookup.

    Paging I/O is excluded at registration because it often runs in System's
    context, not the process whose mapped view was modified. A grant consumed
    at create is carried by the stream-handle context for this handle alone.

    IRQL: <= APC_LEVEL.

--*/
{
    PSAFEUPLOAD_INSTANCE_CONTEXT instanceContext = NULL;
    SAFEUPLOAD_VOLUME_KIND volumeKind;
    ULONG processId;
    NTSTATUS status;

    UNREFERENCED_PARAMETER( CompletionContext = NULL );

    PAGED_CODE();

    if (Data->Iopb->Parameters.Write.Length == 0 ||
        SafeUploadData.ClientPort == NULL) {
        return FLT_PREOP_SUCCESS_NO_CALLBACK;
    }

    processId = FltGetRequestorProcessId( Data );

    if (SafeUploadIsIgnoredProcess( processId ) ||
        !SafeUploadIsProcessTainted( processId ) ||
        SafeUploadHandleHasOverride( FltObjects )) {
        return FLT_PREOP_SUCCESS_NO_CALLBACK;
    }

    status = FltGetInstanceContext( FltObjects->Instance,
                                    (PFLT_CONTEXT *) &instanceContext );

    if (!NT_SUCCESS( status )) {
#if SAFEUPLOAD_STAGING_PROTOTYPE
        volumeKind = SafeUploadVolumeUnknown;
#else
        return FLT_PREOP_SUCCESS_NO_CALLBACK;
#endif
    } else {
        volumeKind = instanceContext->VolumeKind;
        FltReleaseContext( instanceContext );
    }

    if (!SafeUploadIsMonitoredDestination( Data, volumeKind )) {
        return FLT_PREOP_SUCCESS_NO_CALLBACK;
    }

    if (SafeUploadPolicyAuditOnly()) {
        SafeUploadCount( WouldHaveDenied );
        SafeUploadTrace( "AUDITORIA: write seria negado, processo %lu marcado\n",
                         processId );
        return FLT_PREOP_SUCCESS_NO_CALLBACK;
    }

    SafeUploadTrace( "write negado: processo %lu marcado\n", processId );
    Data->IoStatus.Status = STATUS_ACCESS_DENIED;
    Data->IoStatus.Information = 0;
    return FLT_PREOP_COMPLETE;
}


FLT_PREOP_CALLBACK_STATUS
SafeUploadPreCleanup (
    _Inout_ PFLT_CALLBACK_DATA Data,
    _In_ PCFLT_RELATED_OBJECTS FltObjects,
    _Flt_CompletionContext_Outptr_ PVOID *CompletionContext
    )
/*++

Routine Description:

    Pre-operation callback for IRP_MJ_CLEANUP: the last handle to a file
    object is being closed.

    Its only job is to throw away the cached verdict when the handle that is
    closing was opened for write. Cleanup is the right moment because it is
    when the writing is finished; the write callback exists to enforce a
    process taint acquired after the handle was opened.

    Cleanup cannot be failed - the filter manager ignores the return value -
    so nothing here tries to.

    IRQL: PASSIVE_LEVEL.

Arguments:

    Data - Parameters of the operation.

    FltObjects - Objects affected by the operation.

    CompletionContext - Unused.

Return Value:

    FLT_PREOP_SUCCESS_NO_CALLBACK.

--*/
{
    PSAFEUPLOAD_STREAM_CONTEXT streamContext = NULL;
    NTSTATUS status;

    UNREFERENCED_PARAMETER( CompletionContext = NULL );

    PAGED_CODE();

    UNREFERENCED_PARAMETER( Data );

    if (!SafeUploadHandleWasOpenedForWrite( FltObjects )) {

        return FLT_PREOP_SUCCESS_NO_CALLBACK;
    }

    status = FltGetStreamContext( FltObjects->Instance,
                                  FltObjects->FileObject,
                                  (PFLT_CONTEXT *) &streamContext );

    if (!NT_SUCCESS( status )) {

        return FLT_PREOP_SUCCESS_NO_CALLBACK;
    }

    FltAcquirePushLockExclusive( &streamContext->Lock );

    streamContext->Dirty = TRUE;

    FltReleasePushLock( &streamContext->Lock );

    FltReleaseContext( streamContext );

    return FLT_PREOP_SUCCESS_NO_CALLBACK;
}


FLT_PREOP_CALLBACK_STATUS
SafeUploadPreSetInformation (
    _Inout_ PFLT_CALLBACK_DATA Data,
    _In_ PCFLT_RELATED_OBJECTS FltObjects,
    _Flt_CompletionContext_Outptr_ PVOID *CompletionContext
    )
/*++

Routine Description:

    Pre-operation callback for IRP_MJ_SET_INFORMATION, registered for one
    reason: rename and hard link can put a file somewhere the create path
    never saw it go.

    The bypass this closes is concrete. A tainted process cannot create a
    file for writing inside a monitored cloud folder - pre-create refuses
    it. But it can write the same content to an ordinary folder on the same
    volume, which nothing objects to, and then rename it into the monitored
    folder. The file arrives complete, and without this callback nothing
    would have been asked.

    A hard link is the same bypass wearing a different name: it makes the
    content reachable through a path inside the monitored destination
    without moving or copying anything.

    Deletion is deliberately not intercepted. Removing a file is not a way
    to get data out of the machine, and refusing deletes would break far
    more than it protects.

    IRQL: PASSIVE_LEVEL.

Arguments:

    Data - Parameters of the operation.

    FltObjects - Objects affected by the operation.

    CompletionContext - Unused: no post-operation callback is registered.

Return Value:

    FLT_PREOP_COMPLETE with STATUS_ACCESS_DENIED when a tainted process is
    moving content into a monitored destination, FLT_PREOP_SUCCESS_NO_CALLBACK
    otherwise.

--*/
{
    FILE_INFORMATION_CLASS informationClass;
    PFILE_RENAME_INFORMATION renameInformation;
    PFLT_FILE_NAME_INFORMATION nameInfo = NULL;
    PSAFEUPLOAD_INSTANCE_CONTEXT instanceContext = NULL;
    SAFEUPLOAD_VOLUME_KIND volumeKind;
    ULONG processId;
    BOOLEAN monitored = FALSE;
    BOOLEAN isLink;
    NTSTATUS status;

    UNREFERENCED_PARAMETER( CompletionContext = NULL );

    PAGED_CODE();

    if (FltObjects->Transaction != NULL &&
        SafeUploadStageTxfSetInformationMustRefuse(Data, FltObjects)) {
        SafeUploadStageTxfRecordRefused();
        Data->IoStatus.Status = STATUS_ACCESS_DENIED;
        Data->IoStatus.Information = 0;
        return FLT_PREOP_COMPLETE;
    }

    SafeUploadCount( SetInformationSeen );

    informationClass = Data->Iopb->Parameters.SetFileInformation.FileInformationClass;

    //
    //  Record the class before any gate rejects it. Which classes arrive
    //  is exactly what cannot be deduced from the outside, and guessing it
    //  has already cost two deploy-and-test cycles.
    //

    if ((ULONG) informationClass < 64) {

        InterlockedOr64( (volatile LONG64 *) &SafeUploadCounters.ClassesSeenLow,
                         1ULL << (ULONG) informationClass );

    } else if ((ULONG) informationClass < 128) {

        InterlockedOr64( (volatile LONG64 *) &SafeUploadCounters.ClassesSeenHigh,
                         1ULL << ((ULONG) informationClass - 64) );
    }

    //
    //  The cheapest gate available: IRP_MJ_SET_INFORMATION carries dozens of
    //  classes - timestamps, attributes, allocation size, end of file - and
    //  only these four move content to a new path. One comparison rejects
    //  everything else.
    //

    if (informationClass != FileRenameInformation &&
        informationClass != FileRenameInformationEx &&
        informationClass != FileLinkInformation &&
        informationClass != FileLinkInformationEx) {

        return FLT_PREOP_SUCCESS_NO_CALLBACK;
    }



    if (SafeUploadData.ClientPort == NULL) {

        return FLT_PREOP_SUCCESS_NO_CALLBACK;
    }

    isLink = (BOOLEAN) (informationClass == FileLinkInformation ||
                        informationClass == FileLinkInformationEx);

    if (isLink) {
        SafeUploadCount( LinksSeen );
    } else {
        SafeUploadCount( RenamesSeen );
    }

    processId = FltGetRequestorProcessId( Data );

    if (SafeUploadIsIgnoredProcess( processId )) {

        return FLT_PREOP_SUCCESS_NO_CALLBACK;
    }

    //
    //  Taint before destination, for the same reason as in pre-create:
    //  resolving the destination name is the expensive part, and only a
    //  tainted process can be refused, so only a tainted process should pay
    //  for it.
    //

    if (!SafeUploadIsProcessTainted( processId )) {

        return FLT_PREOP_SUCCESS_NO_CALLBACK;
    }

    if (isLink) {
        SafeUploadCount( LinksFromTainted );
    } else {
        SafeUploadCount( RenamesFromTainted );
    }

    status = FltGetInstanceContext( FltObjects->Instance,
                                    (PFLT_CONTEXT *) &instanceContext );

    if (!NT_SUCCESS( status )) {
#if SAFEUPLOAD_STAGING_PROTOTYPE
        volumeKind = SafeUploadVolumeUnknown;
#else
        return FLT_PREOP_SUCCESS_NO_CALLBACK;
#endif
    } else {
        volumeKind = instanceContext->VolumeKind;
        FltReleaseContext( instanceContext );
    }

    //
    //  FILE_LINK_INFORMATION shares its leading layout with
    //  FILE_RENAME_INFORMATION - root directory, name length, name - so one
    //  cast serves both.
    //
    //  The name that matters is the DESTINATION, not the file being
    //  renamed, and it may be relative to a root directory handle.
    //  FltGetDestinationFileNameInformation exists precisely to resolve
    //  that pair into a full path.
    //

    renameInformation =
        (PFILE_RENAME_INFORMATION) Data->Iopb->Parameters.SetFileInformation.InfoBuffer;

    if (renameInformation == NULL) {

        return FLT_PREOP_SUCCESS_NO_CALLBACK;
    }

    status = FltGetDestinationFileNameInformation( FltObjects->Instance,
                                                   FltObjects->FileObject,
                                                   renameInformation->RootDirectory,
                                                   renameInformation->FileName,
                                                   renameInformation->FileNameLength,
                                                   FLT_FILE_NAME_OPENED |
                                                       FLT_FILE_NAME_QUERY_DEFAULT,
                                                   &nameInfo );

    if (NT_SUCCESS( status )) {

        monitored = SafeUploadPolicyMatchesDestination( volumeKind, &nameInfo->Name );

        FltReleaseFileNameInformation( nameInfo );
#if SAFEUPLOAD_STAGING_PROTOTYPE
    } else if (volumeKind == SafeUploadVolumeUnknown) {
        /* A failed destination query cannot prove that this is outside an enabled broad scope. */
        monitored = TRUE;
#endif
    }

    if (!monitored) {

        return FLT_PREOP_SUCCESS_NO_CALLBACK;
    }

    if (SafeUploadPolicyAuditOnly()) {

        SafeUploadCount( WouldHaveDenied );

        SafeUploadTrace( "AUDITORIA: rename seria negado, processo %lu marcado\n", processId );

        return FLT_PREOP_SUCCESS_NO_CALLBACK;
    }

    SafeUploadCount( DeniedRename );

    SafeUploadTrace( "rename negado: processo %lu marcado\n", processId );

    Data->IoStatus.Status = STATUS_ACCESS_DENIED;
    Data->IoStatus.Information = 0;

    return FLT_PREOP_COMPLETE;
}
