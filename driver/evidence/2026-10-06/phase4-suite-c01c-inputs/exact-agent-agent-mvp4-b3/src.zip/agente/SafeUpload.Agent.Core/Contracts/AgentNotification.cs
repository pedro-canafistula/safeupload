using System.Text.Json.Serialization;
using SafeUpload.Agent.Core.Domain;

namespace SafeUpload.Agent.Core.Contracts;

/// <summary>
/// Uma mensagem do serviço para o aplicativo de bandeja.
///
/// O canal de notificações é de mão única: o serviço decide e o aplicativo
/// mostra. A justificativa usa outro contrato e outro pipe; o serviço valida
/// o bloqueio antes de conceder uma nova tentativa.
///
/// Os contratos vivem no <c>Core</c> para que os dois processos compartilhem a
/// mesma definição sem um terceiro projeto só para isso. Continuam livres de
/// arquivo, pipe e HTTP: são apenas a forma dos dados.
/// </summary>
[JsonPolymorphic(TypeDiscriminatorPropertyName = "type")]
[JsonDerivedType(typeof(StatusNotification), StatusNotification.TypeName)]
[JsonDerivedType(typeof(EventNotification), EventNotification.TypeName)]
[JsonDerivedType(typeof(TransferNotification), TransferNotification.TypeName)]
public abstract record AgentNotification;

/// <summary>Progress of a file held locally before release to a protected destination.</summary>
public enum TransferPhase
{
    Analyzing,
    Released,
    Blocked,
    Retained
}

/// <summary>
/// Tells the user that a staged write has finished locally and is being checked.
/// Only metadata crosses the notification pipe; the file stays in the private
/// staging directory until the service has decided whether to release it.
/// </summary>
public sealed record TransferNotification(
    Guid TransferId,
    string FileName,
    TransferPhase Phase,
    IReadOnlyList<Finding>? Findings = null,
    bool OverrideAllowed = false) : AgentNotification
{
    public const string TypeName = "transfer";
}

/// <summary>Current admission-gate coverage for the accepted minifilter policy.</summary>
public enum AdmissionCoverageStatus
{
    NotAvailable,
    Pending,
    Ready,
    Degraded
}

/// <summary>
/// O estado da proteção agora.
///
/// Enviada assim que um cliente conecta e sempre que a política mudar. É o que
/// alimenta os três cartões da tela de status: sem ela o aplicativo não teria
/// como saber a versão da política, já que quem carrega política passou a ser
/// o serviço.
/// </summary>
/// <param name="PolicyVersion">Versão da política em vigor.</param>
/// <param name="ActiveCategories">Quantas categorias estão ativas.</param>
/// <param name="ProtectionActive">
/// Se o interceptador está de fato vigiando. Falso quando o serviço subiu mas
/// não conseguiu observar as pastas — o aplicativo precisa poder distinguir
/// "protegido" de "serviço no ar, mas cego".
/// </param>
/// <param name="AuditOnly">Há observação ativa, mas nenhuma operação é bloqueada.</param>
public sealed record StatusNotification(
    int PolicyVersion,
    int ActiveCategories,
    bool ProtectionActive,
    bool AuditOnly = false,
    AdmissionCoverageStatus AdmissionCoverage = AdmissionCoverageStatus.NotAvailable,
    string? AdmissionCoverageReason = null,
    uint? NativePolicyGeneration = null) : AgentNotification
{
    /// <summary>Discriminador desta mensagem no NDJSON.</summary>
    public const string TypeName = "status";
}

/// <summary>
/// Uma operação julgada.
///
/// Alimenta a atividade recente e, quando o veredito é bloqueio, dispara a
/// notificação. O <see cref="AuditEvent"/> vai aninhado, e não achatado na
/// raiz da mensagem, para que exista uma definição só dos dezessete campos da
/// HU-04: achatar exigiria repetir todos eles aqui e abriria espaço para os
/// dois lados divergirem com o tempo. O discriminador continua na raiz, então
/// quem lê decide o que fazer com a linha sem desserializar o resto.
/// </summary>
/// <param name="Event">O evento de auditoria, exatamente como foi gravado.</param>
/// <param name="Findings">
/// Os achados, já mascarados, com a categoria de cada trecho.
///
/// Vão separados porque o <see cref="AuditEvent"/> guarda categorias e trechos
/// como duas listas distintas, sem preservar o par: um arquivo com dois CPFs
/// diferentes registra uma categoria e dois trechos. Casá-los por posição
/// funciona no caso comum e erra exatamente quando há mais de um achado da
/// mesma categoria — que é quando a notificação mais precisa estar certa. A
/// trilha em disco continua com os dezessete campos da HU-04 inalterados.
/// </param>
public sealed record EventNotification(
    AuditEvent Event,
    IReadOnlyList<Finding> Findings,
    bool OverrideAllowed = false,
    bool Quarantined = false) : AgentNotification
{
    /// <summary>Discriminador desta mensagem no NDJSON.</summary>
    public const string TypeName = "event";
}
